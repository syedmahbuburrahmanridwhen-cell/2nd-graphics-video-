// SFX সিন্থেসাইজার — কোনো ডাউনলোড নেই, ফলাফল নির্ধারিত (seeded noise)।
// ব্যবহার: node scripts/make-sfx.mjs  →  public/sfx/*.wav
import { writeFileSync, mkdirSync } from "node:fs";

const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url);
mkdirSync(OUT, { recursive: true });

let seed = 1337;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.round(sec * SR));
const TAU = Math.PI * 2;

// ফিল্টার
const lowpass = (x, fc) => { const a = 1 - Math.exp(-TAU * fc / SR); let y = 0; return x.map((v) => (y += a * (v - y))); };
const highpass = (x, fc) => { const lp = lowpass(x, fc); return x.map((v, i) => v - lp[i]); };
// সুইপ-সেন্টার band-pass (state-variable)
const sweepBand = (x, f0, f1, q = 0.45) => {
  const y = new Float32Array(x.length); let low = 0, band = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / x.length, fc = f0 * Math.pow(f1 / f0, t);
    const f = 2 * Math.sin(Math.PI * fc / SR);
    low += f * band; const high = x[i] - low - q * band; band += f * high; y[i] = band;
  }
  return y;
};
// খুব ছোট reverb (৩টি comb tap)
const reverb = (x, wet = 0.12) => {
  const taps = [[0.023, 0.34], [0.031, 0.28], [0.043, 0.22]];
  const y = new Float32Array(x.length + Math.round(0.08 * SR)); y.set(x);
  for (const [d, g] of taps) { const n = Math.round(d * SR); for (let i = 0; i < x.length; i++) y[i + n] += x[i] * g * wet * 3; }
  return y;
};
const env = (i, n, att, dec) => { const t = i / SR; const a = Math.min(1, t / att); return a * Math.exp(-t / dec); };

// ১) pop — দ্রুত নিচে নামা pitch + sine
const pop = () => {
  const n = Math.round(0.2 * SR), x = buf(0.2); let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR, f = 170 + 420 * Math.exp(-t / 0.028);
    ph += TAU * f / SR; x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env(i, n, 0.004, 0.045);
  }
  return lowpass(x, 5200);
};
// ২) click — high-pass noise burst + ক্ষুদ্র টিক
const click = () => {
  const n = Math.round(0.09 * SR), x = buf(0.09);
  for (let i = 0; i < n; i++) x[i] = (rnd() * 0.8 + 0.5 * Math.sin(TAU * 2100 * i / SR)) * env(i, n, 0.0015, 0.011);
  return lowpass(highpass(x, 2200), 9000);
};
// ৩) whoosh — band-pass noise sweep + fade in/out
const whoosh = (dur, f0, f1) => () => {
  const n = Math.round(dur * SR), x = buf(dur);
  for (let i = 0; i < n; i++) { const t = i / n; x[i] = rnd() * Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 2); }
  return lowpass(sweepBand(x, f0, f1), 6500);
};
// ৪) chime — নরম ওভারটোনসহ ছোট decay
const chime = () => {
  const n = Math.round(0.42 * SR), x = buf(0.42);
  const partials = [[1, 1], [2.01, 0.38], [3.02, 0.14], [4.2, 0.05]];
  for (let i = 0; i < n; i++) {
    let s = 0; for (const [m, g] of partials) s += g * Math.sin(TAU * 784 * m * i / SR) * Math.exp(-(i / SR) / (0.16 / (0.6 + 0.4 * m)));
    x[i] = s * Math.min(1, (i / SR) / 0.006) * Math.min(1, (n - i) / (0.06 * SR));
  }
  return lowpass(x, 6000);
};
// ৫) thud — খুব হালকা সফট থাড (হুক/মূল বার্তা)
const thud = () => {
  const n = Math.round(0.4 * SR), x = buf(0.4); let ph = 0;
  for (let i = 0; i < n; i++) { const t = i / SR, f = 46 + 58 * Math.exp(-t / 0.05); ph += TAU * f / SR; x[i] = Math.sin(ph) * env(i, n, 0.008, 0.11); }
  return lowpass(x, 420);
};

const kit = {
  pop: { fn: pop, max: 0.5 }, click: { fn: click, max: 0.5, trim: 0.6 },
  whoosh: { fn: whoosh(0.7, 380, 2600), max: 0.8 }, swipe: { fn: whoosh(0.42, 700, 3600), max: 0.8 },
  chime: { fn: chime, max: 0.5 }, thud: { fn: thud, max: 0.5 },
};

const TARGET_RMS = 0.085, PEAK_CAP = 0.9;
const rows = [];
for (const [name, { fn, max, trim = 1 }] of Object.entries(kit)) {
  let x = reverb(Float32Array.from(fn()));
  const rmsOf = (a) => Math.sqrt(a.reduce((s, v) => s + v * v, 0) / a.length);
  const peakOf = (a) => a.reduce((m, v) => Math.max(m, Math.abs(v)), 0);
  // এক স্তরে মেলানো: RMS লক্ষ্য, কিন্তু peak সীমার নিচে
  let g = TARGET_RMS / rmsOf(x); g = Math.min(g, PEAK_CAP / peakOf(x)) * trim;
  x = x.map((v) => v * g);
  // শেষে ছোট fade-out যাতে ক্লিক না হয়
  const fade = Math.round(0.01 * SR); for (let i = 0; i < fade; i++) x[x.length - 1 - i] *= i / fade;
  // WAV (16-bit mono)
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVEfmt ", 8); pcm.writeUInt32LE(16, 16);
  pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22); pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28);
  pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34); pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  let clipped = 0;
  x.forEach((v, i) => { const s = Math.max(-1, Math.min(1, v)); if (Math.abs(s) >= 0.999) clipped++; pcm.writeInt16LE(Math.round(s * 32767), 44 + i * 2); });
  writeFileSync(new URL(`${name}.wav`, OUT), pcm);
  const dur = x.length / SR;
  rows.push({ name, dur: +dur.toFixed(3), peak: +peakOf(x).toFixed(3), rms: +rmsOf(x).toFixed(3), clipped, ok: dur <= max && clipped === 0 && peakOf(x) < 0.95 });
}
console.table(rows);
if (rows.some((r) => !r.ok)) { console.error("SFX CHECK FAILED"); process.exit(1); }
console.log("SFX OK");
