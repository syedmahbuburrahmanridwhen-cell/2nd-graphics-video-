// SRT -> src/cues.ts. SRT-ই একমাত্র সময়-নির্দেশক: SRT বদলালে `npm run cues` চালান।
import { readFileSync, writeFileSync } from "node:fs";

const raw = readFileSync(new URL("../script/2nd_video.srt", import.meta.url), "utf8").replace(/\r/g, "");
const ts = (s) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};
const cues = raw
  .split(/\n\s*\n/)
  .map((b) => b.trim().split("\n"))
  .filter((l) => l.length >= 3)
  .map((l) => {
    const [a, b] = l[1].split("-->");
    return { n: +l[0], start: ts(a), end: ts(b), text: l.slice(2).join(" ").replace(/\s+/g, " ").trim() };
  });

const out =
  `// AUTO-GENERATED from script/2nd_video.srt — হাতে বদলাবেন না।\n` +
  `export type Cue = { n: number; start: number; end: number; text: string };\n` +
  `export const cues: Cue[] = ${JSON.stringify(cues, null, 2)};\n`;
writeFileSync(new URL("../src/cues.ts", import.meta.url), out);
console.log(`cues: ${cues.length}, ends at ${cues[cues.length - 1].end}s`);
