import React from "react";
import { Img, staticFile, useCurrentFrame } from "remotion";
import { Cursor, IconCheck, IconFolder, IconStar, IconUpload } from "../components/Icons";
import { Appear, Pill, Words, tween, useBreath } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Browser, Glass, Shot } from "../components/UI";
import { alpha, theme } from "../theme";

const c = theme.colors;
const ZONE = { l: 880, t: 270, w: 840, h: 540 };

export const S07Netlify: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const breath = useBreath(28, 0.012);
  const tLogo = w(13, "Netlify");
  const tDrag = w(13, "Just drag");
  const dropAt = tDrag + 34;
  const tFast = w(13, "মুহূর্তের");
  const tLive = w(14, "হয়ে গেল");
  const tStart = w(14, "Startup");
  const tBest = w(14, "best");

  // ফোল্ডার ড্র্যাগ: ডান-ওপর থেকে ড্রপজোনের কেন্দ্রে
  const drag = tween(frame, [tDrag, dropAt], [0, 1], theme.ease.inOut);
  const fx = 1560 + (1300 - 1560) * drag;
  const fy = 120 + (520 - 120) * drag;
  const dropped = frame >= dropAt;
  const shrink = tween(frame, [dropAt, dropAt + 10], [1, 0], theme.ease.in);
  const ripple = tween(frame, [dropAt, dropAt + 22], [0, 1], theme.ease.out);
  const ring = tween(frame, [tFast, tFast + 26], [0, 1], theme.ease.soft);
  const live = tween(frame, [tLive, tLive + 18], [0, 1], theme.ease.out);
  const shift = tween(frame, [tStart - 16, tStart + 6], [0, 1], theme.ease.inOut);
  const R = 90;
  const circ = 2 * Math.PI * R;

  return (
    <SceneShell variant={1}>
      <Sfx name="chime" at={tLogo} />
      <Sfx name="whoosh" at={tLogo + 4} vary={1} />
      <Sfx name="pop" at={tDrag} />
      <Sfx name="click" at={dropAt} />
      <Sfx name="swipe" at={tFast} vary={1} />
      <Sfx name="chime" at={tLive} vary={1} />
      <Sfx name="pop" at={tStart + 6} vary={1} />
      <Sfx name="pop" at={tStart + 16} vary={2} />
      <Sfx name="click" at={tBest + 4} vary={1} />

      {/* Netlify লোগো কার্ড */}
      <Appear at={tLogo} until={tStart - 8} y={60} cfg={theme.spring.bouncy} from={0.7} style={{ position: "absolute", left: 140, top: 250 }}>
        <div style={{ transform: `scale(${breath})` }}>
          <Glass radius={64} glow style={{ width: 400, height: 400, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Img src={staticFile("netlify.png")} style={{ width: 250, height: 250 }} />
          </Glass>
        </div>
        <div style={{ marginTop: 34, display: "flex", justifyContent: "center" }}>
          <Words text="Netlify" at={tLogo + 6} size={76} per={4} align="center" />
        </div>
      </Appear>

      {/* ড্রপজোন → লাইভ ব্রাউজার */}
      <div style={{ position: "absolute", left: ZONE.l - 600 * shift, top: ZONE.t, width: ZONE.w, height: ZONE.h, transform: `scale(${1 - 0.1 * shift})`, transformOrigin: "0 50%" }}>
        <Appear at={tLogo + 8} y={50} cfg={theme.spring.smooth} until={tLive + 6} style={{ position: "absolute", inset: 0 }}>
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: 40,
              border: `3px dashed ${dropped ? alpha(c.hero, 0.9) : c.line}`,
              background: dropped ? c.heroSoft : c.surface,
              boxShadow: dropped ? `0 0 ${50 + 40 * ripple}px ${c.glow}` : "none",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 20,
            }}
          >
            {frame < tFast ? (
              <>
                <IconUpload size={92} color={c.textDim} />
                <Pill tone="dim" size={34}>
                  Drag &amp; drop
                </Pill>
              </>
            ) : (
              <svg width={260} height={260} viewBox="0 0 220 220">
                <circle cx="110" cy="110" r={R} stroke={c.line} strokeWidth="14" fill="none" />
                <circle cx="110" cy="110" r={R} stroke={c.accent} strokeWidth="14" fill="none" strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - ring)} transform="rotate(-90 110 110)" />
              </svg>
            )}
          </div>
        </Appear>

        <Appear at={tLive} y={40} cfg={theme.spring.bouncy} from={0.88} style={{ position: "absolute", inset: 0 }}>
          <Browser width={ZONE.w} height={ZONE.h} url="ridwen.netlify.app" glow>
            <Shot zoomTo={1.04} pan={14} />
          </Browser>
          <div style={{ position: "absolute", right: 28, top: 76, display: "flex" }}>
            <Pill tone="hero" size={30}>
              <span style={{ width: 16, height: 16, borderRadius: 99, background: c.ink, opacity: 0.55 + 0.45 * Math.abs(Math.sin(frame / 8)) }} />
              LIVE
            </Pill>
          </div>
        </Appear>
      </div>

      {/* ড্র্যাগ করা ফোল্ডার + কার্সর */}
      {frame >= tDrag && !dropped && (
        <div style={{ position: "absolute", left: fx - 60, top: fy - 60, opacity: Math.min(1, (frame - tDrag) / 6) }}>
          <IconFolder size={120} color={c.accent} />
          <div style={{ position: "absolute", left: 70, top: 70 }}>
            <Cursor size={60} />
          </div>
        </div>
      )}
      {dropped && shrink > 0 && (
        <div style={{ position: "absolute", left: 1300 - 60, top: 520 - 60, transform: `scale(${shrink})` }}>
          <IconFolder size={120} color={c.accent} />
        </div>
      )}

      {/* চিপস: Startup / নতুনদের জন্য / best */}
      <div style={{ position: "absolute", left: 1180, top: 290, display: "flex", flexDirection: "column", gap: 36, alignItems: "flex-start" }}>
        <Appear at={tStart + 4} y={30} cfg={theme.spring.pop} from={0.6}>
          <Pill tone="accent" size={66}>
            Startup
          </Pill>
        </Appear>
        <Appear at={tStart + 14} y={30} cfg={theme.spring.pop} from={0.6}>
          <Pill tone="dim" size={66}>
            নতুনদের জন্য
          </Pill>
        </Appear>
        <Appear at={tBest} y={30} cfg={theme.spring.pop} from={0.6}>
          <Pill tone="hero" size={66}>
            <IconStar size={70} color={c.ink} />
            একদম best
          </Pill>
        </Appear>
      </div>

      {/* সফল টিক */}
      <Appear at={dropAt + 4} until={tFast} y={0} cfg={theme.spring.pop} from={0.4} style={{ position: "absolute", left: ZONE.l + ZONE.w - 130, top: ZONE.t + 30 }}>
        <div style={{ width: 80, height: 80, borderRadius: "50%", background: c.accent, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <IconCheck size={48} color={c.ink} stroke={3.4} />
        </div>
      </Appear>
    </SceneShell>
  );
};
