import React from "react";
import { useCurrentFrame } from "remotion";
import { IconCheck, IconCross, IconPerson, IconSparkle } from "../components/Icons";
import { Appear, Pill, Words, tween, useBreath, useSpr } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { alpha, theme } from "../theme";

const c = theme.colors;

const Badge: React.FC<{ at: number; ok: boolean }> = ({ at, ok }) => {
  const p = useSpr(at, theme.spring.pop);
  return (
    <div
      style={{
        width: 132,
        height: 132,
        borderRadius: "50%",
        flexShrink: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transform: `scale(${p})`,
        background: ok ? c.accentSoft : c.surface,
        border: `2.5px solid ${ok ? alpha(c.accent, 0.7) : c.line}`,
        boxShadow: ok ? `0 0 50px ${c.glowAccent}` : "none",
      }}
    >
      {ok ? <IconCheck size={74} color={c.accent} stroke={3} /> : <IconCross size={70} color={c.textDim} stroke={3} />}
    </div>
  );
};

export const S02Truth: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const r1 = w(3);
  const r2 = w(3, "আবার");
  const r2w = w(3, "অনেকাংশে একদমই");
  const shift = w(3, "ধরুন");
  const k = tween(frame, [shift, shift + 22], [0, 1], theme.ease.inOut);
  const breath = useBreath(30, 0.01);

  return (
    <SceneShell variant={1}>
      <Sfx name="whoosh" at={r1 - 2} />
      <Sfx name="click" at={r1 + 8} />
      <Sfx name="whoosh" at={r2w - 2} vary={1} />
      <Sfx name="click" at={r2w + 8} vary={1} />
      <Sfx name="pop" at={shift + 8} />

      {/* সত্য / ভুল — উল্লম্ব স্ট্যাক (পরের সিনের পাশাপাশি লেআউটের থেকে আলাদা) */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          transform: `translateY(${-120 * k}px) scale(${(1 - 0.24 * k) * breath})`,
          transformOrigin: "50% 42%",
        }}
      >
        <div style={{ position: "absolute", left: 0, right: 0, top: 215, display: "flex", justifyContent: "center", alignItems: "center", gap: 44 }}>
          <Badge at={r1 + 6} ok />
          <Words text="অনেকাংশে *সত্য*" at={r1} size={128} per={5} />
        </div>
        <Appear at={r2} y={20} cfg={theme.spring.snappy} style={{ position: "absolute", left: 0, right: 0, top: 462, display: "flex", justifyContent: "center" }}>
          <Pill tone="dim" size={34}>
            আবার
          </Pill>
        </Appear>
        <div style={{ position: "absolute", left: 0, right: 0, top: 570, display: "flex", justifyContent: "center", alignItems: "center", gap: 44 }}>
          <Badge at={r2w + 6} ok={false} />
          <Words text="অনেকাংশে ভুল" at={r2w} size={128} per={5} color={c.textDim} />
        </div>
      </div>

      {/* "একজন সাধারণ মানুষ AI ব্যবহার" — পরের সিনের প্রি-ভিজ্যুয়াল */}
      <Appear at={shift + 8} y={50} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 0, right: 0, top: 780, display: "flex", justifyContent: "center", alignItems: "center", gap: 34 }}>
        <Pill tone="dim" size={50}>
          <IconPerson size={52} color={c.text} />
          একজন সাধারণ মানুষ
        </Pill>
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 64, color: c.textDim, letterSpacing: 0 }}>+</div>
        <Pill tone="hero" size={50}>
          <IconSparkle size={52} color={c.ink} />
          AI
        </Pill>
      </Appear>
    </SceneShell>
  );
};
