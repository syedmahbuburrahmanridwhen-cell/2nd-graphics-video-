import React from "react";
import { random, useCurrentFrame } from "remotion";
import { Cursor, IconPlay } from "../components/Icons";
import { Appear, Words, tween, useBreath, useFloat, useSpr } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Glass, Shot } from "../components/UI";
import { alpha, theme } from "../theme";

const c = theme.colors;

/** ফোন মকআপ — স্ক্রিনে ইউজারের আসল স্ক্রিনশট (Ken Burns সহ) */
const Phone: React.FC = () => {
  const bezel = 14;
  const W = 470;
  const H = 880;
  return (
    <div
      style={{
        width: W,
        height: H,
        borderRadius: 70,
        background: c.bg,
        border: `${bezel}px solid ${alpha(c.text, 0.16)}`,
        boxShadow: `${theme.shadow.card}, 0 0 90px ${c.glow}`,
        overflow: "hidden",
        position: "relative",
      }}
    >
      <div style={{ position: "absolute", inset: 0 }}>
        <Shot zoomTo={1.1} pan={120} />
      </div>
      <div style={{ position: "absolute", top: 14, left: "50%", marginLeft: -48, width: 96, height: 26, borderRadius: 99, background: c.bg }} />
    </div>
  );
};

/** অন্তহীন কোড-স্ক্রল (শুধু ব্লক-লাইন) */
const CodeScroll: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const W = 700;
  const H = 700;
  const lines = Array.from({ length: 64 }).map((_, i) => ({
    indent: Math.floor(random(`i${i}`) * 4) * 36,
    len: 120 + random(`l${i}`) * 380,
    tone: [c.accent, c.hero, c.text, c.textDim][Math.floor(random(`t${i}`) * 4)],
  }));
  const y = -(frame - at) * 5.2;
  return (
    <Glass radius={theme.radius.md} style={{ width: W, height: H, overflow: "hidden", position: "relative" }}>
      <div style={{ height: 56, display: "flex", alignItems: "center", gap: 10, padding: "0 22px", borderBottom: `1.5px solid ${c.lineSoft}` }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ width: 13, height: 13, borderRadius: 99, background: i === 0 ? c.textDim : c.line }} />
        ))}
      </div>
      <div style={{ position: "absolute", left: 28, top: 84, right: 56, bottom: 0, overflow: "hidden", maskImage: "linear-gradient(180deg, transparent 0, black 10%, black 82%, transparent 100%)", WebkitMaskImage: "linear-gradient(180deg, transparent 0, black 10%, black 82%, transparent 100%)" }}>
        <div style={{ transform: `translateY(${y % (64 * 34)}px)` }}>
          {[...lines, ...lines].map((l, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", height: 34 }}>
              <div style={{ width: 40, height: 8, borderRadius: 4, background: alpha(c.textDim, 0.35), marginRight: 22 }} />
              <div style={{ marginLeft: l.indent, width: l.len, height: 12, borderRadius: 6, background: alpha(l.tone, 0.65) }} />
            </div>
          ))}
        </div>
      </div>
      {/* স্ক্রলবার থাম্ব — ফাইল কত লম্বা */}
      <div style={{ position: "absolute", right: 18, top: 84, bottom: 24, width: 8, borderRadius: 99, background: c.lineSoft }}>
        <div style={{ width: 8, height: 44, borderRadius: 99, background: c.hero, transform: `translateY(${Math.min(60, (frame - at) * 0.5)}px)` }} />
      </div>
    </Glass>
  );
};

export const S05Promise: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const a = w(8, "গত video");
  const a2 = w(8, "নিজের");
  const b = w(9, "তবে একটা");
  const cStart = w(9, "তাও চলুন");
  const clickAt = Math.max(cStart + 30, w(10) - 20);

  const phoneP = useSpr(a, theme.spring.bouncy);
  const floatY = useFloat(34, 7);
  const breath = useBreath(30, 0.01);

  // কার্সর: বাটনের দিকে এসে ক্লিক
  const cur = tween(frame, [cStart + 16, clickAt - 6], [0, 1], theme.ease.inOut);
  const press = tween(frame, [clickAt, clickAt + 5], [0, 1], theme.ease.out) - tween(frame, [clickAt + 5, clickAt + 12], [0, 1], theme.ease.out);
  const ripple = tween(frame, [clickAt, clickAt + 20], [0, 1], theme.ease.out);

  return (
    <SceneShell variant={1}>
      <Sfx name="pop" at={a} />
      <Sfx name="whoosh" at={a + 2} vary={1} />
      <Sfx name="whoosh" at={b} vary={2} />
      <Sfx name="pop" at={b + 8} vary={1} />
      <Sfx name="whoosh" at={cStart} vary={3} />
      <Sfx name="click" at={clickAt} />

      {/* বিট A: প্রতিশ্রুতি */}
      <div style={{ position: "absolute", left: 120, top: 300, width: 1000 }}>
        <Words text="গত video-র" at={a} until={b + 2} size={104} per={5} color={c.textDim} />
        <div style={{ height: 4 }} />
        <Words text="*প্রতিশ্রুতি*" at={a + 6} until={b + 2} size={168} per={5} />
        <div style={{ height: 30 }} />
        <Words text="নিজের professional website" at={a2} until={b + 2} size={58} per={4} />
      </div>
      <Appear at={a} until={b + 6} y={0} from={1} style={{ position: "absolute", left: 1220, top: 80 }}>
        <div style={{ transform: `translateY(${(1 - phoneP) * 140 + floatY}px) rotate(${-4 + (1 - phoneP) * 8}deg) scale(${breath})`, opacity: Math.min(1, phoneP * 1.5) }}>
          <Phone />
        </div>
      </Appear>

      {/* বিট B: পুরো code লেখা সম্ভব নয় */}
      <Appear at={b + 4} until={cStart + 2} y={50} cfg={theme.spring.smooth} style={{ position: "absolute", left: 140, top: 190 }}>
        <CodeScroll at={b + 4} />
      </Appear>
      <div style={{ position: "absolute", left: 930, top: 300, width: 860 }}>
        <Words text="একটা video-তে" at={b + 8} until={cStart + 2} size={92} per={5} color={c.textDim} />
        <Words text="পুরো code লেখা" at={b + 14} until={cStart + 2} size={92} per={5} />
        <div style={{ height: 12 }} />
        <Words text="*সম্ভব~নয়*" at={b + 22} until={cStart + 2} size={158} per={6} />
      </div>

      {/* বিট C: তাও চলুন — স্টার্ট বাটন */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 250, display: "flex", justifyContent: "center" }}>
        <Words text="তাও *চলুন*" at={cStart + 2} size={168} per={6} align="center" />
      </div>
      <Appear at={cStart + 10} y={60} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 960 - 110, top: 560 }}>
        <div style={{ position: "relative", transform: `scale(${1 - 0.06 * press})` }}>
          <div
            style={{
              width: 220,
              height: 220,
              borderRadius: "50%",
              background: c.hero,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: `0 0 ${60 + 30 * ripple}px ${c.glow}`,
            }}
          >
            <IconPlay size={96} color={c.ink} />
          </div>
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              border: `3px solid ${alpha(c.accent, 0.7 * (1 - ripple))}`,
              transform: `scale(${1 + ripple * 0.9})`,
            }}
          />
          <div style={{ position: "absolute", left: 130 + 360 * (1 - cur), top: 130 + 300 * (1 - cur), opacity: Math.min(1, cur * 3) }}>
            <Cursor size={72} />
          </div>
        </div>
      </Appear>
    </SceneShell>
  );
};
