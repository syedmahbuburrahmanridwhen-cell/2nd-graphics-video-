import React from "react";
import { useCurrentFrame } from "remotion";
import { IconCheck, IconPerson, IconCode } from "../components/Icons";
import { Appear, Pill, Words, tween, useFloat } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Browser, Glass, SiteMock } from "../components/UI";
import { alpha, theme } from "../theme";

const c = theme.colors;
const BW = 780;
const BH = 500;

export const S03Compare: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const left = w(4); // "একটা website বানাল"
  const right = w(4, "professional");
  const gap = w(5, "আকাশ");
  const win = w(5, "অবশ্যই");
  const floatL = useFloat(34, 5, 0);
  const floatR = useFloat(34, 5, 2);
  const dimK = tween(frame, [win, win + 18], [0, 1], theme.ease.inOut);
  const spread = tween(frame, [gap, gap + 24], [0, 1], theme.ease.inOut);

  return (
    <SceneShell variant={2}>
      <Sfx name="pop" at={left + 2} />
      <Sfx name="pop" at={right + 2} vary={1} />
      <Sfx name="whoosh" at={gap - 2} />
      <Sfx name="click" at={win + 10} />

      {/* বাম: সাধারণ মানুষ + AI */}
      <div style={{ position: "absolute", left: 150 - 50 * spread, top: 160, width: BW, opacity: 1 - 0.55 * dimK, transform: `scale(${1 - 0.04 * dimK})`, transformOrigin: "50% 40%" }}>
        <Appear at={left} y={30} style={{ display: "flex", justifyContent: "center", marginBottom: 34 }}>
          <Pill tone="dim" size={40}>
            <IconPerson size={40} color={c.text} />
            সাধারণ মানুষ + AI
          </Pill>
        </Appear>
        <Appear at={left + 4} y={60} cfg={theme.spring.smooth} style={{ transform: undefined }}>
          <div style={{ transform: `translateY(${floatL}px)` }}>
            <Browser width={BW} height={BH} url="">
              <SiteMock polished={false} at={left + 14} per={5} />
            </Browser>
          </div>
        </Appear>
      </div>

      {/* ডান: Professional Developer + AI */}
      <div style={{ position: "absolute", left: 990 + 50 * spread, top: 160, width: BW }}>
        <Appear at={right} y={30} style={{ display: "flex", justifyContent: "center", marginBottom: 34 }}>
          <Pill tone="hero" size={40}>
            <IconCode size={40} color={c.ink} />
            Professional Developer + AI
          </Pill>
        </Appear>
        <Appear at={right + 4} y={60} cfg={theme.spring.smooth}>
          <div style={{ transform: `translateY(${floatR}px) scale(${1 + 0.03 * dimK})` }}>
            <Browser width={BW} height={BH} url="" glow={dimK > 0.5}>
              <SiteMock polished at={right + 14} per={4} />
            </Browser>
          </div>
        </Appear>
        {/* জয়ের ব্যাজ */}
        <Appear at={win + 4} cfg={theme.spring.pop} from={0.3} y={10} style={{ position: "absolute", right: -26, top: 60 }}>
          <div
            style={{
              width: 104,
              height: 104,
              borderRadius: "50%",
              background: c.accent,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: `0 0 50px ${c.glowAccent}`,
            }}
          >
            <IconCheck size={62} color={c.ink} stroke={3.2} />
          </div>
        </Appear>
      </div>

      {/* VS */}
      <Appear at={right + 8} cfg={theme.spring.pop} from={0.4} y={10} until={gap + 4} style={{ position: "absolute", left: 960 - 58, top: 370 }}>
        <Glass radius={999} style={{ width: 116, height: 116, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 44, color: c.text, letterSpacing: 0 }}>
          VS
        </Glass>
      </Appear>

      {/* "আকাশ-পাতাল তফাৎ" */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 830, display: "flex", justifyContent: "center" }}>
        <Words text="আকাশ-পাতাল *তফাৎ*" at={gap} size={112} per={5} align="center" />
      </div>
    </SceneShell>
  );
};
