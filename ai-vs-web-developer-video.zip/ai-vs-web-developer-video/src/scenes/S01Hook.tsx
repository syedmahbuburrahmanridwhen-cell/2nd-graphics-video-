import React from "react";
import { useCurrentFrame } from "remotion";
import { Glass } from "../components/UI";
import { IconBolt, IconCode, IconGlobe, IconQuestion } from "../components/Icons";
import { Appear, Words, tween, useBreath, useSpr } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { alpha, theme } from "../theme";

const c = theme.colors;

/** AI অর্ব: রিং + কোর + কক্ষপথের চিপ */
const Orb: React.FC<{ cx: number; cy: number; size: number; at: number }> = ({ cx, cy, size, at }) => {
  const frame = useCurrentFrame();
  const core = useSpr(at, theme.spring.bouncy);
  const breath = useBreath(24, 0.025);
  const chips = [IconCode, IconGlobe, IconBolt];
  return (
    <div style={{ position: "absolute", left: cx - size, top: cy - size, width: size * 2, height: size * 2 }}>
      {[0, 1, 2, 3].map((i) => {
        const p = useSpr(at + 6 + i * 5, theme.spring.smooth);
        const r = size * (0.62 + i * 0.2) * (0.7 + 0.3 * p) * (1 + Math.sin(frame / 26 + i) * 0.012);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: size - r,
              top: size - r,
              width: r * 2,
              height: r * 2,
              borderRadius: "50%",
              border: `${i === 0 ? 3 : 2}px solid ${alpha(i === 0 ? c.hero : c.accent, 0.5 - i * 0.1)}`,
              opacity: Math.min(1, p * 1.5),
            }}
          />
        );
      })}
      <div
        style={{
          position: "absolute",
          left: size - size * 0.5,
          top: size - size * 0.5,
          width: size,
          height: size,
          borderRadius: "50%",
          transform: `scale(${core * breath})`,
          opacity: Math.min(1, core * 1.5),
          background: `radial-gradient(circle at 35% 30%, ${alpha(c.hero, 0.9)}, ${alpha(c.hero, 0.35)} 55%, ${c.bgAlt} 100%)`,
          boxShadow: `0 0 90px ${c.glow}, 0 0 180px ${alpha(c.hero, 0.22)}, inset 0 0 60px ${alpha(c.text, 0.12)}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontFamily: theme.fonts.display,
          fontWeight: theme.weight.bold,
          fontSize: size * 0.44,
          color: c.text,
          letterSpacing: 0,
          textShadow: `0 0 40px ${c.glow}`,
        }}
      >
        AI
      </div>
      {chips.map((Icon, i) => {
        const p = useSpr(at + 22 + i * 6, theme.spring.pop);
        const ang = frame / 42 + (i * Math.PI * 2) / 3;
        const rad = size * 0.98;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: size + Math.cos(ang) * rad - 46,
              top: size + Math.sin(ang) * rad * 0.62 - 46,
              opacity: Math.min(1, p * 1.5),
              transform: `scale(${p})`,
            }}
          >
            <Glass radius={26} style={{ width: 92, height: 92, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Icon size={46} color={c.accent} />
            </Glass>
          </div>
        );
      })}
    </div>
  );
};

export const S01Hook: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const q = w(2); // cue 2: "developer বা coder পুরোপুরি replace করে দেবে?"
  const move = tween(frame, [q, q + 26], [0, 1], theme.ease.inOut);
  const orbX = 1500 + (1560 - 1500) * move;
  const orbY = 520 + (330 - 520) * move;
  const orbR = 280 + (190 - 280) * move; // অর্বের স্কেল (কোরের ব্যাস = size)

  return (
    <SceneShell variant={0}>
      <Sfx name="thud" at={6} />
      <Sfx name="whoosh" at={w(1) - 2} />
      <Sfx name="pop" at={w(1, "প্রশ্ন")} />
      <Sfx name="whoosh" at={q - 2} vary={1} />
      <Sfx name="pop" at={q + 10} vary={2} />

      {/* ভিজ্যুয়াল: AI অর্ব (ডানে) */}
      <Orb cx={orbX} cy={orbY} size={orbR} at={2} />

      {/* কিউ ১: "AI industry এখন বিশাল" */}
      <div style={{ position: "absolute", left: 120, top: 330, width: 1100 }}>
        <Words text="*AI* industry" at={w(1)} until={q + 2} size={150} per={5} />
        <div style={{ height: 14 }} />
        <Words text="এখন *বিশাল*" at={w(1, "এত বড়")} until={q + 2} size={124} per={5} />
      </div>

      {/* প্রশ্নবোধক ব্যাজ */}
      <Appear at={w(1, "প্রশ্ন")} cfg={theme.spring.pop} y={20} from={0.4} style={{ position: "absolute", left: 1100, top: 150 }}>
        <Glass radius={999} glow style={{ width: 120, height: 120, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <IconQuestion size={64} color={c.accent} stroke={2.6} />
        </Glass>
      </Appear>

      {/* কিউ ২: প্রশ্নটা */}
      <div style={{ position: "absolute", left: 120, top: 270, width: 1100 }}>
        <Words text="AI কি তবে" at={q} size={84} per={4} color={c.textDim} />
        <div style={{ height: 8 }} />
        <Words text="Web~Developer" at={q + 6} size={118} per={5} />
        <div style={{ height: 6 }} />
        <Words text="*replace* করে দেবে?" at={q + 14} size={118} per={5} />
      </div>

      {/* কোডার কার্ড */}
      <Appear at={q + 8} cfg={theme.spring.bouncy} y={70} from={0.7} style={{ position: "absolute", left: 1210, top: 640 }}>
        <Glass radius={44} style={{ width: 300, height: 300, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <IconCode size={160} color={c.accent} stroke={1.8} />
        </Glass>
      </Appear>
    </SceneShell>
  );
};
