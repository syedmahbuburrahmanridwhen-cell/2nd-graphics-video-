import React from "react";
import { IconPerson } from "../components/Icons";
import { Appear, Words, useBreath, useFloat } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Glass } from "../components/UI";
import { useCurrentFrame } from "remotion";
import { alpha, theme } from "../theme";

const c = theme.colors;

const Avatar: React.FC<{ hero?: boolean }> = ({ hero }) => (
  <div style={{ width: 110, height: 110, borderRadius: "50%", flexShrink: 0, background: hero ? c.hero : c.surfaceStrong, border: `2px solid ${hero ? alpha(c.text, 0.4) : c.line}`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: hero ? `0 0 50px ${c.glow}` : "none" }}>
    <IconPerson size={74} color={hero ? c.ink : c.textDim} />
  </div>
);

const Dots: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <div style={{ display: "flex", gap: 12, padding: "0 6px" }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ width: 18, height: 18, borderRadius: 99, background: c.textDim, opacity: 0.4 + 0.6 * Math.max(0, Math.sin(frame / 4 - i)) }} />
      ))}
    </div>
  );
};

export const S08Objection: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const b1 = w(15);
  const dots = w(15, "এটা তো") - 16;
  const b2 = w(15, "এটা তো");
  const b3 = w(15, "আরে ভাই");
  const f1 = useFloat(34, 4, 0);
  const f2 = useFloat(34, 4, 1.5);
  const f3 = useFloat(34, 4, 3);
  const br = useBreath(30, 0.008);

  return (
    <SceneShell variant={0}>
      <Sfx name="pop" at={b1} />
      <Sfx name="pop" at={b2} vary={1} />
      <Sfx name="whoosh" at={b3 - 2} vary={2} />
      <Sfx name="thud" at={b3 + 2} vary={1} />

      {/* ভাই, professional website কোথায়? */}
      <Appear at={b1} y={60} x={-80} cfg={theme.spring.bouncy} from={0.85} style={{ position: "absolute", left: 130, top: 170 }}>
        <div style={{ transform: `translateY(${f1}px)`, display: "flex", alignItems: "center", gap: 30 }}>
          <Avatar />
          <Glass radius={44} style={{ padding: "38px 60px" }}>
            <Words text="ভাই, *professional* website কোথায়?" at={b1 + 4} size={74} per={4} />
          </Glass>
        </div>
      </Appear>

      {/* typing dots */}
      <Appear at={dots} until={b2} y={20} x={80} cfg={theme.spring.snappy} style={{ position: "absolute", left: 1260, top: 470 }}>
        <Glass radius={999} style={{ padding: "26px 34px" }}>
          <Dots />
        </Glass>
      </Appear>

      {/* এটা তো একটা simple page */}
      <Appear at={b2} y={60} x={80} cfg={theme.spring.bouncy} from={0.85} style={{ position: "absolute", right: 130, top: 440 }}>
        <div style={{ transform: `translateY(${f2}px)`, display: "flex", alignItems: "center", gap: 30, flexDirection: "row-reverse" }}>
          <Avatar />
          <Glass radius={44} style={{ padding: "38px 60px" }}>
            <Words text="এটা তো একটা simple page" at={b2 + 4} size={74} per={4} color={c.textDim} />
          </Glass>
        </div>
      </Appear>

      {/* আরে ভাই! */}
      <Appear at={b3} y={70} x={-80} cfg={theme.spring.bouncy} from={0.8} style={{ position: "absolute", left: 130, top: 730 }}>
        <div style={{ transform: `translateY(${f3}px) scale(${br})`, display: "flex", alignItems: "center", gap: 30 }}>
          <Avatar hero />
          <div style={{ padding: "30px 64px", borderRadius: 44, background: c.hero, boxShadow: `0 0 70px ${c.glow}`, fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 96, color: c.ink, letterSpacing: 0, lineHeight: 1.2 }}>আরে ভাই!</div>
        </div>
      </Appear>

    </SceneShell>
  );
};
