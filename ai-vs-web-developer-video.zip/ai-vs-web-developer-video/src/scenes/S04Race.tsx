import React from "react";
import { useCurrentFrame } from "remotion";
import { Glass } from "../components/UI";
import { IconFlag, IconPerson, IconStar } from "../components/Icons";
import { Appear, Pill, Words, tween, useBreath, useSpr } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { wordAt } from "../timing";
import { alpha, heroGradient, theme } from "../theme";

const c = theme.colors;

/** স্পার্ক: ১২টি রে স্ট্যাগার্ডে বেরোয় */
const Spark: React.FC<{ cx: number; cy: number; size: number; at: number }> = ({ cx, cy, size, at }) => {
  const frame = useCurrentFrame();
  const core = useSpr(at, theme.spring.bouncy);
  const breath = useBreath(26, 0.03);
  const rays = 12;
  return (
    <div style={{ position: "absolute", left: cx - size, top: cy - size, width: size * 2, height: size * 2, transform: `rotate(${frame * 0.12}deg)` }}>
      {Array.from({ length: rays }).map((_, i) => {
        const p = useSpr(at + 4 + i * 2, theme.spring.snappy);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: size * 0.07,
              height: size * (i % 2 ? 0.34 : 0.46) * p,
              background: i % 2 ? c.accent : alpha(c.accent, 0.55),
              borderRadius: size,
              transformOrigin: "50% 0%",
              transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.62}px)`,
              opacity: Math.min(1, p * 1.5),
            }}
          />
        );
      })}
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", transform: `rotate(${-frame * 0.12}deg)` }}>
        <div
          style={{
            width: size * 1.05,
            height: size * 1.05,
            borderRadius: "50%",
            transform: `scale(${core * breath})`,
            background: `radial-gradient(circle at 35% 30%, ${alpha(c.hero, 0.9)}, ${alpha(c.hero, 0.4)} 60%, ${c.bgAlt})`,
            boxShadow: `0 0 80px ${c.glow}, inset 0 0 40px ${alpha(c.text, 0.12)}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <IconStar size={size * 0.62} color={c.text} stroke={2} />
        </div>
      </div>
    </div>
  );
};

const LANE_X0 = 260;
const LANE_X1 = 1660;

const Lane: React.FC<{ y: number; progress: number; at: number; hero?: boolean; label: React.ReactNode }> = ({ y, progress, at, hero, label }) => {
  const frame = useCurrentFrame();
  const p = useSpr(at, theme.spring.smooth);
  const x = LANE_X0 + (LANE_X1 - LANE_X0) * progress;
  const bob = Math.sin(frame / 5) * (hero ? 4 : 1.5) * Math.min(1, progress * 8);
  return (
    <div style={{ opacity: Math.min(1, p * 1.5), transform: `translateY(${(1 - p) * 40}px)` }}>
      <div style={{ position: "absolute", left: LANE_X0, top: y - 130 }}>{label}</div>
      {/* ট্র্যাক */}
      <div style={{ position: "absolute", left: LANE_X0, top: y - 11, width: LANE_X1 - LANE_X0, height: 22, borderRadius: 99, background: c.surface, border: `1.5px solid ${c.lineSoft}` }} />
      <div
        style={{
          position: "absolute",
          left: LANE_X0,
          top: y - 11,
          width: Math.max(0, x - LANE_X0),
          height: 22,
          borderRadius: 99,
          background: hero ? heroGradient : alpha(c.textDim, 0.5),
          boxShadow: hero ? `0 0 40px ${c.glow}` : "none",
        }}
      />
      {/* ফিনিশ ফ্ল্যাগ */}
      <div style={{ position: "absolute", left: LANE_X1 - 8, top: y - 76 }}>
        <IconFlag size={64} color={hero ? c.accent : c.textDim} />
      </div>
      {/* রানার */}
      <div
        style={{
          position: "absolute",
          left: x - 40,
          top: y - 40 + bob,
          width: 80,
          height: 80,
          borderRadius: "50%",
          background: hero ? c.hero : c.bgAlt,
          border: `2.5px solid ${hero ? alpha(c.text, 0.5) : c.line}`,
          boxShadow: hero ? `0 0 60px ${c.glow}` : theme.shadow.soft,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <IconPerson size={46} color={hero ? c.ink : c.textDim} />
      </div>
    </div>
  );
};

export const S04Race: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const best = w(6);
  const swapAt = w(6, "আর যারা");
  const raceAt = swapAt;
  const igAt = w(7, "ignore");
  const launch = w(7, "কম দক্ষরাও");
  const right = w(7, "সঠিক");

  // রানার ১: ধীরে, কিছুদূর গিয়ে থেমে যায়
  const p1 = tween(frame, [igAt, igAt + 70], [0, 0.2], theme.ease.soft);
  // রানার ২: থমকে থাকা → ছুটে অনেক এগিয়ে
  const p2a = tween(frame, [launch, launch + 40], [0, 0.46], theme.ease.out);
  const p2b = tween(frame, [right, right + 50], [0, 0.46], theme.ease.out);
  const p2 = p2a + p2b;

  return (
    <SceneShell variant={0}>
      <Sfx name="chime" at={best + 4} />
      <Sfx name="whoosh" at={best} vary={1} />
      <Sfx name="whoosh" at={swapAt} vary={2} />
      <Sfx name="pop" at={raceAt + 12} />
      <Sfx name="pop" at={raceAt + 18} vary={1} />
      <Sfx name="swipe" at={launch} />

      {/* বিট A: সেরাটা বের করে আনবে */}
      <Appear at={0} until={swapAt} y={0} from={1} style={{ position: "absolute", inset: 0 }}>
        <Spark cx={520} cy={540} size={190} at={best} />
        <div style={{ position: "absolute", left: 940, top: 330, width: 860 }}>
          <Words text="*সেরাটা*" at={best + 4} until={swapAt} size={176} per={5} />
          <div style={{ height: 6 }} />
          <Words text="বের করে আনবে" at={best + 12} until={swapAt} size={96} per={5} />
        </div>
        <Appear at={best + 22} y={30} style={{ position: "absolute", left: 944, top: 720 }}>
          <Pill tone="accent" size={38}>
            <IconStar size={42} color={c.accent} />
            Professional Developer
          </Pill>
        </Appear>
      </Appear>

      {/* বিট B: রেস */}
      <Appear at={raceAt} y={0} from={1} style={{ position: "absolute", inset: 0 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 120, display: "flex", justifyContent: "center" }}>
          <Words text="AI-র সঠিক ব্যবহারেই *এগিয়ে*" at={raceAt + 2} size={72} per={4} align="center" />
        </div>
        <Lane
          y={500}
          progress={p1}
          at={raceAt + 8}
          label={
            <Pill tone="dim" size={38}>
              AI ignore করেছে
            </Pill>
          }
        />
        <Lane
          y={770}
          progress={Math.min(0.94, p2)}
          at={raceAt + 14}
          hero
          label={
            <Pill tone="hero" size={38}>
              AI-র সঠিক ব্যবহার
            </Pill>
          }
        />
      </Appear>
    </SceneShell>
  );
};
