import React from "react";
import { IconMail } from "../components/Icons";
import { Appear, Pill, Words, tween, useBreath, useFloat } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Browser, Glass, Shot } from "../components/UI";
import { useCurrentFrame } from "remotion";
import { alpha, heroGradient, theme } from "../theme";

const c = theme.colors;

export const S10Cta: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const tVisit = w(18, "visit");
  const tUrl = w(18, "ridwen");
  const tBtn = w(19, "আমাকে");
  const tThanks = w(19, "ধন্যবাদ");
  const fl = useFloat(36, 6);
  const br = useBreath(28, 0.012);
  const press = tween(frame, [tBtn + 22, tBtn + 26], [0, 1], theme.ease.out) * (1 - tween(frame, [tBtn + 28, tBtn + 36], [0, 1], theme.ease.out));
  const pulse = 0.5 + 0.5 * Math.sin(frame / 12);

  return (
    <SceneShell variant={1}>
      <Sfx name="pop" at={4} />
      <Sfx name="whoosh" at={tVisit} />
      <Sfx name="chime" at={tUrl} />
      <Sfx name="pop" at={tBtn} vary={1} />
      <Sfx name="click" at={tBtn + 22} />
      <Sfx name="whoosh" at={tThanks - 2} vary={1} />

      <Appear at={2} y={70} cfg={theme.spring.smooth} style={{ position: "absolute", left: 120, top: 220 }}>
        <div style={{ transform: `translateY(${fl}px)` }}>
          <Browser width={900} height={640} url="ridwen.netlify.app" glow>
            <Shot zoomTo={1.08} pan={220} />
          </Browser>
        </div>
      </Appear>

      <div style={{ position: "absolute", left: 1090, top: 200, width: 720 }}>
        <Words text="এখনই *visit* করুন" at={tVisit} size={84} per={5} />
      </div>

      <Appear at={tUrl} y={50} cfg={theme.spring.bouncy} from={0.9} style={{ position: "absolute", left: 1090, top: 340 }}>
        <div style={{ transform: `scale(${br})`, transformOrigin: "0 50%" }}>
          <Glass radius={36} glow style={{ padding: "34px 40px", width: 700 }}>
            <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 60, letterSpacing: 0, whiteSpace: "nowrap", backgroundImage: heroGradient, WebkitBackgroundClip: "text", backgroundClip: "text", WebkitTextFillColor: "transparent", padding: "0.1em 0" }}>ridwen.netlify.app</div>
          </Glass>
        </div>
      </Appear>

      <Appear at={w(18, "অথবা")} y={30} cfg={theme.spring.snappy} style={{ position: "absolute", left: 1090, top: 530 }}>
        <Pill tone="dim" size={34}>অথবা সরাসরি</Pill>
      </Appear>

      <Appear at={tBtn} y={50} cfg={theme.spring.bouncy} from={0.8} style={{ position: "absolute", left: 1090, top: 640 }}>
        <div style={{ transform: `scale(${1 - 0.05 * press})` }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 20, padding: "30px 60px", borderRadius: 999, background: c.hero, fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 58, color: c.ink, letterSpacing: 0, boxShadow: `0 0 ${50 + 30 * pulse}px ${c.glow}` }}>
            <IconMail size={64} color={c.ink} stroke={2.4} />
            Inbox করুন
          </div>
        </div>
      </Appear>

      <div style={{ position: "absolute", left: 1090, top: 830 }}>
        <Words text="*ধন্যবাদ*" at={tThanks} size={104} per={5} />
      </div>
    </SceneShell>
  );
};
