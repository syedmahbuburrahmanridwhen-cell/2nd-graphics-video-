import React from "react";
import { Img, staticFile, useCurrentFrame } from "remotion";
import { IconBolt, IconCheck, IconSparkle } from "../components/Icons";
import { Appear, Pill, Words, tween, useFloat } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Browser, Glass, Shot } from "../components/UI";
import { alpha, theme } from "../theme";

const c = theme.colors;

// ইউজারের সাইটের আসল ফাইল (index.html) থেকে নেওয়া ছোট কোড-অংশ
const CODE = [
  "<!DOCTYPE html>",
  '<html lang="en">',
  "<head>",
  "  <title>Portfolio</title>",
  "  <style>",
  "    body { background: #050505; }",
  "  </style>",
  "</head>",
  "<body>",
  '  <section id="hero">',
  "    <h1>I build websites &amp; apps.</h1>",
  '    <a class="btn">View my work</a>',
  "  </section>",
  "</body>",
  "</html>",
];
const TOTAL_CHARS = CODE.reduce((s, l) => s + l.length, 0);

type Seg = { t: string; col: string };
const colorize = (line: string): Seg[] => {
  const re = /(<\/?[A-Za-z!][A-Za-z0-9!]*|\/?>|"[^"]*"|#[0-9a-fA-F]{3,6}|[{};:])/g;
  const out: Seg[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(line))) {
    if (m.index > last) out.push({ t: line.slice(last, m.index), col: c.text });
    const tok = m[0];
    const col = tok.startsWith("<") || tok.endsWith(">") ? c.accent : tok.startsWith('"') || tok.startsWith("#") ? c.hero : c.textDim;
    out.push({ t: tok, col });
    last = m.index + tok.length;
  }
  if (last < line.length) out.push({ t: line.slice(last), col: c.text });
  return out;
};

const WIN = { l: 120, t: 150, w: 1680, h: 740 };
const TITLE_H = 52;
const ACT_W = 68;
const SIDE_W = 250;

const Editor: React.FC<{ chars: number; saved: boolean; typing: boolean }> = ({ chars, saved, typing }) => {
  const frame = useCurrentFrame();
  let left = chars;
  const caretOn = Math.floor(frame / 15) % 2 === 0;
  let acc = 0;
  const caretLine = Math.max(0, CODE.findIndex((l) => (acc += l.length) >= chars));
  return (
    <div style={{ position: "absolute", left: ACT_W + SIDE_W, top: TITLE_H, right: 0, bottom: 0 }}>
      {/* ট্যাব */}
      <div style={{ height: 48, display: "flex", alignItems: "stretch", borderBottom: `1.5px solid ${c.lineSoft}`, background: c.surface }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "0 26px", borderRight: `1.5px solid ${c.lineSoft}`, borderTop: `2.5px solid ${c.hero}`, background: c.bgAlt, fontFamily: theme.fonts.mono, fontSize: 21, color: c.text, letterSpacing: 0 }}>
          index.html
          <div style={{ width: 12, height: 12, borderRadius: 99, background: saved ? "transparent" : c.textDim, border: saved ? `2px solid ${c.accent}` : "none", transition: "none" }} />
        </div>
      </div>
      <div style={{ padding: "18px 0 0 0", fontFamily: theme.fonts.mono, fontSize: 24, letterSpacing: 0 }}>
        {CODE.map((line, i) => {
          const show = Math.max(0, Math.min(line.length, left));
          left -= line.length;
          let rem = show;
          const segs = colorize(line);
          return (
            <div key={i} style={{ display: "flex", height: 40, alignItems: "center" }}>
              <div style={{ width: 70, textAlign: "right", paddingRight: 24, color: alpha(c.textDim, 0.6) }}>{i + 1}</div>
              <div style={{ whiteSpace: "pre" }}>
                {segs.map((sg, k) => {
                  const part = sg.t.slice(0, Math.max(0, rem));
                  rem -= sg.t.length;
                  return part ? (
                    <span key={k} style={{ color: sg.col }}>
                      {part}
                    </span>
                  ) : null;
                })}
                {typing && i === caretLine && caretOn ? <span style={{ display: "inline-block", width: 12, height: 28, background: c.accent, verticalAlign: "middle", marginLeft: 2 }} /> : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const Sidebar: React.FC<{ at: number }> = ({ at }) => (
  <div style={{ position: "absolute", left: ACT_W, top: TITLE_H, bottom: 0, width: SIDE_W, borderRight: `1.5px solid ${c.lineSoft}`, padding: "22px 18px" }}>
    <div style={{ fontFamily: theme.fonts.mono, fontSize: 16, color: c.textDim, letterSpacing: 0, marginBottom: 18 }}>EXPLORER</div>
    {[0, 1, 2, 3].map((i) => (
      <Appear key={i} at={at + i * 4} y={14} from={0.96} cfg={theme.spring.snappy}>
        <div
          style={{
            height: 40,
            borderRadius: 10,
            marginBottom: 8,
            display: "flex",
            alignItems: "center",
            padding: "0 14px",
            background: i === 0 ? c.heroSoft : "transparent",
            fontFamily: theme.fonts.mono,
            fontSize: 20,
            letterSpacing: 0,
            color: i === 0 ? c.text : c.textDim,
          }}
        >
          {i === 0 ? "index.html" : <div style={{ width: [150, 110, 130][i - 1], height: 10, borderRadius: 5, background: alpha(c.textDim, 0.35) }} />}
        </div>
      </Appear>
    ))}
  </div>
);

const ActivityBar: React.FC = () => (
  <div style={{ position: "absolute", left: 0, top: TITLE_H, bottom: 0, width: ACT_W, borderRight: `1.5px solid ${c.lineSoft}`, background: c.surface, display: "flex", flexDirection: "column", alignItems: "center", gap: 26, paddingTop: 26 }}>
    {[0, 1, 2, 3].map((i) => (
      <div key={i} style={{ width: 28, height: 28, borderRadius: 8, border: `2.5px solid ${i === 0 ? c.text : alpha(c.textDim, 0.6)}` }} />
    ))}
  </div>
);

const AiPane: React.FC<{ at: number; smartAt: number }> = ({ at, smartAt }) => {
  const frame = useCurrentFrame();
  const bars = [0.92, 0.7, 0.84, 0.5, 0.78];
  return (
    <Glass radius={26} style={{ width: 520, height: 640, padding: 30, position: "relative" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 30 }}>
        <IconSparkle size={46} color={c.accent} />
        <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 36, color: c.text, letterSpacing: 0 }}>AI</div>
      </div>
      {bars.map((b, i) => {
        const prog = tween(frame, [at + 12 + i * 10, at + 34 + i * 10], [0, 1], theme.ease.out);
        return (
          <div key={i} style={{ height: 18, width: `${b * 100}%`, borderRadius: 9, background: alpha(c.textDim, 0.18), marginBottom: 20, overflow: "hidden" }}>
            <div style={{ width: `${prog * 100}%`, height: "100%", background: i % 2 ? alpha(c.accent, 0.75) : alpha(c.hero, 0.75), borderRadius: 9 }} />
          </div>
        );
      })}
      <Appear at={smartAt} y={30} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 30, bottom: 34 }}>
        <Pill tone="accent" size={32}>
          <IconBolt size={36} color={c.accent} />
          Smart work
        </Pill>
      </Appear>
    </Glass>
  );
};

const Key: React.FC<{ label: string; pressed: number; wide?: boolean }> = ({ label, pressed, wide }) => (
  <div
    style={{
      width: wide ? 150 : 96,
      height: 92,
      borderRadius: 22,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: theme.fonts.display,
      fontWeight: theme.weight.bold,
      fontSize: 38,
      letterSpacing: 0,
      color: pressed > 0.5 ? c.ink : c.text,
      background: pressed > 0.5 ? c.hero : `linear-gradient(150deg, ${c.surfaceStrong}, ${c.surface})`,
      border: `1.5px solid ${c.line}`,
      boxShadow: pressed > 0.5 ? `0 0 40px ${c.glow}` : theme.shadow.soft,
      transform: `translateY(${pressed * 8}px) scale(${1 - 0.05 * pressed})`,
    }}
  >
    {label}
  </div>
);

export const S06VSCode: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const floatY = useFloat(40, 4);

  const tWin = w(10);
  const tLogo = w(10, "Visual Studio Code");
  const dockStart = tLogo + 52;
  const dockEnd = dockStart + 22;
  const tAI = w(11, "AI এর");
  const tSmart = w(11, "smart");
  const tPrev = w(12, "এই তো");
  const tComplete = w(12, "complete");
  const tSave = w(12, "file save");

  const dock = tween(frame, [dockStart, dockEnd], [0, 1], theme.ease.inOut);
  const focus = tween(frame, [tLogo - 4, tLogo + 8], [0, 1], theme.ease.out) * (1 - tween(frame, [dockStart, dockStart + 14], [0, 1], theme.ease.inOut));
  const winOpacity = 1 - 0.7 * focus;

  // টাইপিং: AI আসার পর গতি বাড়ে
  const typeStart = dockEnd - 4;
  const base = Math.max(0, frame - typeStart) * 0.55;
  const boost = Math.max(0, frame - tAI) * 2.1;
  const chars = Math.min(TOTAL_CHARS, Math.floor(frame > tAI ? Math.max(0, tAI - typeStart) * 0.55 + boost : base));

  const aiIn = tween(frame, [tAI, tAI + 22], [0, 1], theme.ease.out);
  const swap = tween(frame, [tPrev, tPrev + 16], [0, 1], theme.ease.inOut);
  const press = tween(frame, [tSave + 8, tSave + 12], [0, 1], theme.ease.out) * (1 - tween(frame, [tSave + 14, tSave + 22], [0, 1], theme.ease.out));
  const saved = frame > tSave + 12;

  // লোগো: কেন্দ্র → টাইটেল-বারের স্লট
  const slotX = WIN.l + 100 + 18;
  const slotY = WIN.t + TITLE_H / 2;
  const lx = 960 + (slotX - 960) * dock;
  const ly = 540 + (slotY - 540) * dock;
  const lsize = 250 + (36 - 250) * dock;
  const logoIn = tween(frame, [tLogo, tLogo + 10], [0, 1], theme.ease.out);

  return (
    <SceneShell variant={2}>
      <Sfx name="pop" at={tWin + 2} />
      <Sfx name="chime" at={tLogo} />
      <Sfx name="whoosh" at={dockStart} vary={1} />
      <Sfx name="pop" at={tAI} vary={1} />
      <Sfx name="pop" at={tSmart} vary={2} />
      <Sfx name="swipe" at={tPrev} vary={1} />
      <Sfx name="chime" at={tComplete} vary={1} />
      <Sfx name="click" at={tSave + 8} />

      {/* ক্যাপশন (মূল বাক্যাংশ) */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 48, display: "flex", justifyContent: "center" }}>
        <Words text="কোড লেখার *টুল*" at={tWin + 4} until={w(11, "একা") + 2} size={58} per={5} align="center" />
        <Words text="একা নয়, *AI* এর সাহায্যে" at={w(11, "একা")} until={tSmart + 2} size={58} per={4} align="center" />
        <Words text="*Smart~work* আসল" at={tSmart} until={tPrev + 2} size={58} per={5} align="center" />
        <Words text="Minimal single page *complete*" at={tPrev} until={tSave + 2} size={58} per={4} align="center" />
        <Words text="file *save*" at={tSave} size={58} per={5} align="center" />
      </div>

      {/* উইন্ডো */}
      <Appear at={tWin} y={70} cfg={theme.spring.smooth} style={{ position: "absolute", left: WIN.l, top: WIN.t }}>
        <div
          style={{
            width: WIN.w,
            height: WIN.h,
            borderRadius: 28,
            overflow: "hidden",
            position: "relative",
            background: c.bgAlt,
            border: `1.5px solid ${c.line}`,
            boxShadow: theme.shadow.card,
            opacity: winOpacity,
            transform: `translateY(${floatY}px)`,
          }}
        >
          {/* টাইটেল বার */}
          <div style={{ position: "absolute", left: 0, right: 0, top: 0, height: TITLE_H, background: c.surface, borderBottom: `1.5px solid ${c.lineSoft}`, display: "flex", alignItems: "center", padding: "0 24px", gap: 10 }}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{ width: 14, height: 14, borderRadius: 99, background: i === 0 ? c.textDim : c.line }} />
            ))}
            <div style={{ position: "absolute", left: 0, right: 0, textAlign: "center", fontFamily: theme.fonts.mono, fontSize: 20, color: c.textDim, letterSpacing: 0 }}>index.html</div>
          </div>
          <ActivityBar />
          <Sidebar at={tWin + 10} />
          <Editor chars={chars} saved={saved} typing={frame >= typeStart && chars < TOTAL_CHARS + 1} />

          {/* ডান প্যানেল: AI → প্রিভিউ */}
          <div style={{ position: "absolute", right: 22, top: TITLE_H + 24, width: 520, height: 640, transform: `translateX(${(1 - aiIn) * 560}px)`, opacity: aiIn }}>
            <div style={{ position: "absolute", inset: 0, opacity: 1 - swap, transform: `scale(${1 - 0.04 * swap})` }}>
              <AiPane at={tAI} smartAt={tSmart} />
            </div>
            <div style={{ position: "absolute", inset: 0, opacity: swap, transform: `translateY(${(1 - swap) * 30}px)` }}>
              <Browser width={520} height={640} url="index.html" glow={frame > tComplete}>
                <Shot zoomTo={1.06} pan={90} />
              </Browser>
              <Appear at={tComplete} y={20} cfg={theme.spring.pop} from={0.5} style={{ position: "absolute", right: 24, top: 76 }}>
                <Pill tone="hero" size={32}>
                  <IconCheck size={36} color={c.ink} stroke={3} />
                  Complete
                </Pill>
              </Appear>
            </div>
          </div>

        </div>
      </Appear>

      {/* Ctrl + S (উইন্ডোর নিচে, কোডের ওপরে নয়) */}
          <Appear at={tSave} y={40} cfg={theme.spring.bouncy} style={{ position: "absolute", left: WIN.l + ACT_W + SIDE_W + 40, top: 925 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              <Key label="Ctrl" pressed={press} wide />
              <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.bold, fontSize: 40, color: c.textDim, letterSpacing: 0 }}>+</div>
              <Key label="S" pressed={press} />
            </div>
          </Appear>

      {/* বড় লোগো রিভিল → উইন্ডোতে ডক */}
      {frame >= tLogo && (
        <>
          <div style={{ position: "absolute", left: 960 - 190, top: 540 - 190, width: 380, height: 380, opacity: logoIn * (1 - dock), transform: `scale(${0.8 + 0.2 * logoIn})` }}>
            <Glass radius={64} glow style={{ width: 380, height: 380 }} />
          </div>
          <Img
            src={staticFile("vscode.png")}
            style={{
              position: "absolute",
              left: lx - lsize / 2,
              top: ly - lsize / 2,
              width: lsize,
              height: lsize,
              opacity: logoIn,
              transform: `scale(${0.7 + 0.3 * logoIn})`,
            }}
          />
          <div style={{ position: "absolute", left: 0, right: 0, top: 780, display: "flex", justifyContent: "center", opacity: 1 - dock }}>
            <Words text="Visual~Studio~Code" at={tLogo + 4} until={dockStart + 8} size={68} per={5} align="center" />
          </div>
        </>
      )}
    </SceneShell>
  );
};
