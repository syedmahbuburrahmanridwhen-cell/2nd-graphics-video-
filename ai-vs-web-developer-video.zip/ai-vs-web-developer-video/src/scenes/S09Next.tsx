import React from "react";
import { useCurrentFrame } from "remotion";
import { IconBriefcase, IconCheck, IconQuestion, IconTag } from "../components/Icons";
import { Appear, Pill, Words, tween, useFloat, useSpr } from "../components/Motion";
import { SceneShell, useW } from "../components/Scene";
import { Sfx } from "../components/Sfx";
import { Browser, Glass, SiteMock } from "../components/UI";
import { alpha, heroGradient, theme } from "../theme";

const c = theme.colors;
const X1 = 480;
const X2 = 1440;
const Y = 600;

const Node: React.FC<{ x: number; at: number; hero?: boolean }> = ({ x, at, hero }) => {
  const p = useSpr(at, theme.spring.pop);
  return (
    <div style={{ position: "absolute", left: x - 26, top: Y - 26, width: 52, height: 52, borderRadius: "50%", transform: `scale(${p})`, background: hero ? c.hero : c.bgAlt, border: `4px solid ${hero ? alpha(c.text, 0.5) : c.accent}`, boxShadow: hero ? `0 0 50px ${c.glow}` : "none" }} />
  );
};

export const S09Next: React.FC = () => {
  const { w } = useW();
  const frame = useCurrentFrame();
  const n1 = w(16);
  const n2 = w(16, "আগামী");
  const done = w(17);
  const swap = w(17, "business", 11);
  const biz = w(17, "business");
  const brand = w(17, "brand");
  const prem = Math.min(w(17, "premium"), brand + 20);
  const line = tween(frame, [n2 - 6, n2 + 34], [0, 1], theme.ease.inOut);
  const f1 = useFloat(36, 5, 0);
  const f2 = useFloat(36, 5, 2);

  return (
    <SceneShell variant={2}>
      <Sfx name="whoosh" at={n1} />
      <Sfx name="pop" at={n1 + 4} />
      <Sfx name="swipe" at={n2 - 4} vary={1} />
      <Sfx name="pop" at={n2 + 30} vary={1} />
      <Sfx name="chime" at={done + 4} />
      <Sfx name="whoosh" at={swap} vary={2} />
      <Sfx name="pop" at={biz} vary={1} />
      <Sfx name="pop" at={brand} vary={2} />
      <Sfx name="chime" at={prem} vary={1} />

      {/* বিট A: এই video → আগামী video */}
      <Appear at={0} until={swap} y={0} from={1} style={{ position: "absolute", inset: 0 }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: 92, display: "flex", justifyContent: "center" }}>
          <Words text="এক video-তে সব হলে *interest* থাকে?" at={n1} until={swap + 2} size={62} per={4} align="center" />
        </div>
        {/* টাইমলাইন লাইন */}
        <div style={{ position: "absolute", left: X1, top: Y - 4, width: X2 - X1, height: 8, borderRadius: 99, background: c.lineSoft }} />
        <div style={{ position: "absolute", left: X1, top: Y - 4, width: (X2 - X1) * line, height: 8, borderRadius: 99, background: heroGradient, boxShadow: `0 0 30px ${c.glow}` }} />
        <Node x={X1} at={n1 + 6} />
        <Node x={X2} at={n2 + 34} hero />

        {/* নোড ১ */}
        <Appear at={n1 + 6} y={60} cfg={theme.spring.smooth} style={{ position: "absolute", left: X1 - 260, top: 200 }}>
          <div style={{ transform: `translateY(${f1}px)` }}>
            <Browser width={520} height={330} url="">
              <SiteMock polished minimal at={n1 + 16} per={4} />
            </Browser>
          </div>
        </Appear>
        <Appear at={n1 + 14} y={30} style={{ position: "absolute", left: X1 - 260, top: 680, width: 520, display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
          <Words text="এই video" at={n1 + 14} size={56} per={4} align="center" />
          <Pill tone="dim" size={30}>Minimal single page</Pill>
        </Appear>

        {/* ভবিষ্যৎ নোডের জায়গা (ড্যাশড প্লেসহোল্ডার) */}
        <Appear at={n1 + 26} until={n2 + 38} y={40} cfg={theme.spring.smooth} style={{ position: "absolute", left: X2 - 260, top: 200 }}>
          <div style={{ width: 520, height: 330, borderRadius: 24, border: `3px dashed ${c.line}`, background: c.surface, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <IconQuestion size={110} color={c.textDim} stroke={1.8} />
          </div>
        </Appear>

        {/* নোড ২ */}
        <Appear at={n2 + 34} y={60} cfg={theme.spring.smooth} style={{ position: "absolute", left: X2 - 260, top: 200 }}>
          <div style={{ transform: `translateY(${f2}px)` }}>
            <Browser width={520} height={330} url="" glow>
              <SiteMock polished at={n2 + 44} per={3} />
            </Browser>
          </div>
        </Appear>
        <Appear at={n2 + 40} y={30} style={{ position: "absolute", left: X2 - 260, top: 680, width: 520, display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
          <Words text="আগামী video" at={n2 + 40} size={56} per={4} align="center" />
          <Pill tone="hero" size={30}>
            <IconCheck size={34} color={c.ink} stroke={3} />
            Complete website
          </Pill>
        </Appear>
      </Appear>

      {/* বিট B: Bento — business, brand, premium website */}
      <Appear at={swap + 2} y={0} from={1} style={{ position: "absolute", inset: 0 }}>
        <Appear at={biz} y={50} cfg={theme.spring.bouncy} from={0.9} style={{ position: "absolute", left: 140, top: 190 }}>
          <Glass radius={40} style={{ width: 560, height: 330, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 22 }}>
            <IconBriefcase size={110} color={c.accent} stroke={1.8} />
            <Words text="Business" at={biz + 4} size={64} per={4} align="center" />
          </Glass>
        </Appear>
        <Appear at={brand} y={50} cfg={theme.spring.bouncy} from={0.9} style={{ position: "absolute", left: 140, top: 560 }}>
          <Glass radius={40} style={{ width: 560, height: 330, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 22 }}>
            <IconTag size={110} color={c.accent} stroke={1.8} />
            <Words text="Brand" at={brand + 4} size={64} per={4} align="center" />
          </Glass>
        </Appear>
        <Appear at={prem} y={60} cfg={theme.spring.bouncy} from={0.9} style={{ position: "absolute", left: 740, top: 190 }}>
          <Glass radius={40} glow style={{ width: 1040, height: 700, padding: 36 }}>
            <Browser width={968} height={520} url="" glow>
              <SiteMock polished at={prem + 8} per={3} />
            </Browser>
            <div style={{ marginTop: 24, display: "flex", justifyContent: "center" }}>
              <Words text="Premium *website*" at={prem + 10} size={60} per={5} align="center" />
            </div>
          </Glass>
        </Appear>
      </Appear>
    </SceneShell>
  );
};
