import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import "./fonts";
import { SceneCtx } from "./components/Scene";
import { PreviewAudio, Sfx } from "./components/Sfx";
import { TransitionPanel } from "./components/Transition";
import { S01Hook } from "./scenes/S01Hook";
import { S02Truth } from "./scenes/S02Truth";
import { S03Compare } from "./scenes/S03Compare";
import { S04Race } from "./scenes/S04Race";
import { S05Promise } from "./scenes/S05Promise";
import { S06VSCode } from "./scenes/S06VSCode";
import { S07Netlify } from "./scenes/S07Netlify";
import { S08Objection } from "./scenes/S08Objection";
import { S09Next } from "./scenes/S09Next";
import { S10Cta } from "./scenes/S10Cta";
import { TRANSITION_FRAMES, SceneId, scenes } from "./timing";
import { theme } from "./theme";

const MAP: Record<SceneId, React.FC> = {
  hook: S01Hook,
  truth: S02Truth,
  compare: S03Compare,
  race: S04Race,
  promise: S05Promise,
  vscode: S06VSCode,
  netlify: S07Netlify,
  objection: S08Objection,
  next: S09Next,
  cta: S10Cta,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    {scenes.map((s) => {
      const Comp = MAP[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration}>
          <SceneCtx.Provider value={{ from: s.from }}>
            <Comp />
          </SceneCtx.Provider>
        </Sequence>
      );
    })}
    {scenes.slice(1).map((s, i) => (
      <React.Fragment key={s.id}>
        <Sequence from={s.from - TRANSITION_FRAMES / 2} durationInFrames={TRANSITION_FRAMES}>
          <TransitionPanel />
        </Sequence>
        <Sfx name="swipe" at={s.from - 11} vary={i} />
      </React.Fragment>
    ))}
    <PreviewAudio />
  </AbsoluteFill>
);
