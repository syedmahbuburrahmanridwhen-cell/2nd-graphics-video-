// timing.ts — সব সময়-হিসাব SRT (cues.ts) থেকে। হাতে কিছু বসানো হয়নি।
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_FRAMES = Math.ceil(cues[cues.length - 1].end * FPS);

/** সিন-কাট প্রথম cue-র এত ফ্রেম আগে (ভিজ্যুয়াল কথার আগে ঢোকে) */
export const CUT_LEAD = 6;
/** একই সিনের ভেতরে আইটেম সংশ্লিষ্ট কথার এত ফ্রেম আগে ঢোকে (৪–৬) */
export const LEAD = 5;
/** ট্রানজিশন-প্যানেলের মোট দৈর্ঘ্য */
export const TRANSITION_FRAMES = 16;

const f = (s: number) => Math.round(s * FPS);
export const cueStart = (n: number) => f(cues[n - 1].start);
export const cueEnd = (n: number) => f(cues[n - 1].end);

/**
 * cue-র ভেতরের কোনো শব্দ/বাক্যাংশ কখন বলা হবে — অক্ষরের অনুপাতে আনুমানিক (SRT-তে শব্দ-স্তরের সময় নেই)।
 * অ্যাবসোলিউট ফ্রেম ফেরত দেয়।
 */
export const wordAt = (n: number, sub: string, lead = 0) => {
  const c = cues[n - 1];
  const i = c.text.indexOf(sub);
  if (i < 0) throw new Error(`cue ${n}-এ "${sub}" নেই`);
  const frac = i / c.text.length;
  return f(c.start + frac * (c.end - c.start)) - lead;
};

export type SceneId = "hook" | "truth" | "compare" | "race" | "promise" | "vscode" | "netlify" | "objection" | "next" | "cta";
export const SCENE_DEFS: { id: SceneId; first: number; last: number }[] = [
  { id: "hook", first: 1, last: 2 },
  { id: "truth", first: 3, last: 3 },
  { id: "compare", first: 4, last: 5 },
  { id: "race", first: 6, last: 7 },
  { id: "promise", first: 8, last: 9 },
  { id: "vscode", first: 10, last: 12 },
  { id: "netlify", first: 13, last: 14 },
  { id: "objection", first: 15, last: 15 },
  { id: "next", first: 16, last: 17 },
  { id: "cta", first: 18, last: 19 },
];

export type Scene = { id: SceneId; from: number; to: number; duration: number; first: number; last: number };
export const scenes: Scene[] = SCENE_DEFS.map((d, i) => {
  const from = i === 0 ? 0 : cueStart(d.first) - CUT_LEAD;
  const next = SCENE_DEFS[i + 1];
  const to = next ? cueStart(next.first) - CUT_LEAD : TOTAL_FRAMES;
  return { ...d, from, to, duration: to - from };
});
