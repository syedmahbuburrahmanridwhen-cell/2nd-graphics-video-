// ফন্ট লোডিং। Poppins প্রজেক্টেই আছে (public/fonts), বাংলার জন্য Hind Siliguri @remotion/google-fonts থেকে।
import { continueRender, delayRender, staticFile } from "remotion";
import { loadFont as loadHindSiliguri } from "@remotion/google-fonts/HindSiliguri";

loadHindSiliguri("normal", { weights: ["400", "500", "600", "700"], subsets: ["bengali", "latin"] });

if (typeof document !== "undefined" && "fonts" in document) {
  const handle = delayRender("poppins-fonts");
  const faces: [string, string][] = [
    ["Poppins-Regular.ttf", "400"],
    ["Poppins-Medium.ttf", "500"],
    ["Poppins-Bold.ttf", "700"],
  ];
  Promise.all(
    faces.map(([file, weight]) =>
      new FontFace("Poppins", `url(${staticFile("fonts/" + file)})`, { weight }).load().then((ff) => {
        document.fonts.add(ff);
      }),
    ),
  )
    .catch(() => undefined)
    .finally(() => continueRender(handle));
}
