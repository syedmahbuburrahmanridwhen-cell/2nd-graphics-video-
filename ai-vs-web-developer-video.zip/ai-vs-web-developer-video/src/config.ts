// ফ্ল্যাগ — Studio প্রিভিউ ও রেন্ডার আচরণ এখান থেকে।
export const PREVIEW_VOICEOVER = true; // public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজবে; না থাকলে নীরবে বাদ
export const INCLUDE_VO_IN_RENDER = false; // রেন্ডারে ভয়েসওভার মেশাতে চাইলে true করুন (ডিফল্ট: বন্ধ)
export const ENABLE_SFX = true;
