// AUTO-GENERATED from script/2nd_video.srt — হাতে বদলাবেন না।
export type Cue = { n: number; start: number; end: number; text: string };
export const cues: Cue[] = [
  {
    "n": 1,
    "start": 0.18,
    "end": 6.2,
    "text": "AI এর industry এখন এত বড় হয়ে গেছে যে অনেকেরই মনে প্রশ্ন, AI কি তবে web"
  },
  {
    "n": 2,
    "start": 6.2,
    "end": 8.78,
    "text": "developer বা coder পুরোপুরি replace করে দেবে?"
  },
  {
    "n": 3,
    "start": 9.42,
    "end": 16.4,
    "text": "কথাটা অনেকাংশে সত্য, আবার অনেকাংশে একদমই ভুল। ধরুন, একজন সাধারণ মানুষ AI ব্যবহার"
  },
  {
    "n": 4,
    "start": 16.4,
    "end": 20.48,
    "text": "করে একটা website বানাল। আর একজন professional web developerও AI দিয়ে"
  },
  {
    "n": 5,
    "start": 20.48,
    "end": 25.88,
    "text": "website বানাল। বলুন তো, দুজনের কাজের মধ্যে আকাশ পাতাল তফাৎ হবে নাকি? অবশ্যই"
  },
  {
    "n": 6,
    "start": 25.88,
    "end": 30.74,
    "text": "professional developerই সেরাটা বের করে আনবে। [শ্বাস নেয়] আর যারা ভেবেছিল AI কে"
  },
  {
    "n": 7,
    "start": 30.74,
    "end": 36.2,
    "text": "ignore করবে, তারা আজ টের পাচ্ছে, তাদের চেয়ে কম দক্ষরাও AI এর সঠিক ব্যবহারে"
  },
  {
    "n": 8,
    "start": 36.2,
    "end": 40.9,
    "text": "বহুদূর এগিয়ে গেছে। গত video কথা দিয়েছিলাম নিজের professional website"
  },
  {
    "n": 9,
    "start": 40.9,
    "end": 46.9,
    "text": "বানিয়ে দেখাব। তবে একটা video তো আর পুরো code লিখে শেষ করা সম্ভব নয়। তাও চলুন, আজ"
  },
  {
    "n": 10,
    "start": 46.9,
    "end": 52.22,
    "text": "শুরু করি। Code লেখার জন্য আমি বেছে নিয়েছি Visual Studio Code। আর হ্যাঁ, এখানে আমি"
  },
  {
    "n": 11,
    "start": 52.22,
    "end": 57.86,
    "text": "একা একা সব code লিখিনি। কাজটা দ্রুত শেষ করতে AI এর সাহায্যও নিয়েছি। কারণ smart"
  },
  {
    "n": 12,
    "start": 57.86,
    "end": 63.72,
    "text": "work আসল। এই তো, আমাদের minimal single page মোটামুটি complete। এখন file save করে"
  },
  {
    "n": 13,
    "start": 63.72,
    "end": 68.88,
    "text": "সোজা চলে এলাম Netlify তে। Just drag and drop করলাম, আর মুহূর্তের মধ্যে website"
  },
  {
    "n": 14,
    "start": 68.88,
    "end": 74.92,
    "text": "হয়ে গেল live। Startup বা নতুনদের জন্য এটা একদম best মাধ্যম। অনেকেই হয়তো এখন বলবেন,"
  },
  {
    "n": 15,
    "start": 74.92,
    "end": 80.42,
    "text": "ভাই professional website কোথায়? এটা তো একটা simple page। [হাসির শব্দ] আরে ভাই, এক"
  },
  {
    "n": 16,
    "start": 80.42,
    "end": 85.3,
    "text": "video সব বানিয়ে ফেললে কি আর interest থাকে? সমস্যা নেই, আগামী video তেই পুরো"
  },
  {
    "n": 17,
    "start": 85.3,
    "end": 90.66,
    "text": "website একদম complete করে দেখাব। আর যারা নিজের business বা brand জন্য এমন premium"
  },
  {
    "n": 18,
    "start": 90.66,
    "end": 97.32,
    "text": "website বানাতে চান, তারা দেরি না করে এখনই visit করুন ridwen.netlify.app অথবা সরাসরি"
  },
  {
    "n": 19,
    "start": 97.32,
    "end": 99.08,
    "text": "আমাকে inbox করুন। ধন্যবাদ।"
  }
];
