// theme.ts — একমাত্র সত্য-উৎস: রং, ফন্ট, ইজিং, spring প্রিসেট। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// কালার স্কিম: Midnight Cobalt (ইউজারের নির্বাচন: ১)
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#060A12",
    bgAlt: "#0B1424",
    hero: "#23A9F2", // হিরো — প্রতি ফ্রেমে সর্বোচ্চ ১টি প্রধান উপাদানে
    accent: "#32E6E2",
    text: "#F2F6FA",
    textDim: "#8EA2B8",
    ink: "#060A12", // হিরো রঙের ওপর লেখার রং
    surface: "rgba(242,246,250,0.045)",
    surfaceStrong: "rgba(242,246,250,0.085)",
    line: "rgba(242,246,250,0.12)",
    lineSoft: "rgba(242,246,250,0.07)",
    glow: "rgba(35,169,242,0.42)",
    glowAccent: "rgba(50,230,226,0.30)",
    heroSoft: "rgba(35,169,242,0.16)",
    accentSoft: "rgba(50,230,226,0.14)",
  },
  fonts: {
    // Latin → Poppins, বাংলা → Hind Siliguri (ওয়েবসাইটের ফন্ট স্ট্যাকের মতোই)
    display: '"Poppins", "Hind Siliguri", sans-serif',
    body: '"Poppins", "Hind Siliguri", sans-serif',
    mono: '"JetBrains Mono", ui-monospace, Menlo, Consolas, "DejaVu Sans Mono", monospace',
  },
  weight: { bold: 700, medium: 500, regular: 400 },
  radius: { sm: 14, md: 26, lg: 40, pill: 999 },
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.7), inset 0 1px 0 rgba(242,246,250,0.07)",
    soft: "0 18px 40px -16px rgba(0,0,0,0.6)",
  },
  size: { title: 128, h1: 104, h2: 80, h3: 56, body: 40, small: 30, tiny: 24 },
  // ইজিং: linear নিষিদ্ধ
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    soft: Easing.bezier(0.45, 0, 0.15, 1),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    pop: { damping: 12, stiffness: 220, mass: 0.55 },
  },
} as const;

/** "#RRGGBB" + 0..1 opacity → "#RRGGBBAA" */
export const alpha = (hex: string, o: number) =>
  hex + Math.round(Math.max(0, Math.min(1, o)) * 255).toString(16).padStart(2, "0");

export const heroGradient = `linear-gradient(100deg, ${theme.colors.hero} 0%, ${theme.colors.accent} 100%)`;
export type SpringCfg = { damping: number; stiffness: number; mass: number };
