import React, { createContext, useContext, useMemo } from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { LEAD, cueEnd, cueStart, wordAt } from "../timing";
import { BgMesh, Grade, Grain, Vignette } from "./Layers";

export const SceneCtx = createContext<{ from: number }>({ from: 0 });

/**
 * সিনের লোকাল ফ্রেম-হেল্পার (সব SRT থেকে):
 *  w(n)            → cue n শুরুর ফ্রেম (LEAD আগে)
 *  w(n, "শব্দ")    → cue n-এর ভেতর ওই শব্দ বলার আনুমানিক ফ্রেম (LEAD আগে)
 *  e(n)            → cue n শেষের ফ্রেম
 */
export const useW = () => {
  const { from } = useContext(SceneCtx);
  return useMemo(
    () => ({
      w: (n: number, sub?: string, lead: number = LEAD) =>
        Math.max(4, (sub ? wordAt(n, sub, 0) : cueStart(n)) - lead - from),
      e: (n: number) => cueEnd(n) - from,
    }),
    [from],
  );
};

/** পাঁচ-স্তরের স্ট্যাক: মেশ → অ্যাসেট/গ্রাফিক্স (children) → গ্রেড → গ্রেন + ভিনিয়েট */
export const SceneShell: React.FC<{ variant?: number; children: React.ReactNode }> = ({ variant = 0, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = [durationInFrames - 10, durationInFrames - 1] as [number, number];
  const clampX = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const out = interpolate(frame, t, [0, 1], { easing: theme.ease.in, ...clampX });
  return (
    <AbsoluteFill>
      <BgMesh variant={variant} />
      <AbsoluteFill style={{ opacity: 1 - out, transform: `scale(${1 + out * 0.035})` }}>{children}</AbsoluteFill>
      <Grade />
      <Grain />
      <Vignette />
    </AbsoluteFill>
  );
};
