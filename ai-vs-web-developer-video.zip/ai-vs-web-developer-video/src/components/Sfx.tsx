import React, { useEffect, useState } from "react";
import * as R from "remotion";
import { Audio, Sequence, continueRender, delayRender, staticFile } from "remotion";
import { ENABLE_SFX, INCLUDE_VO_IN_RENDER, PREVIEW_VOICEOVER } from "../config";

const FILES = {
  pop: "sfx/pop.wav", // কার্ড/UI রিভিল
  click: "sfx/click.wav", // বাটন, টিক, হাইলাইট
  whoosh: "sfx/whoosh.wav", // টেক্সট/শিরোনাম এন্ট্রি
  swipe: "sfx/swipe.wav", // সিন ট্রানজিশন
  chime: "sfx/chime.wav", // লোগো রিভিল
  thud: "sfx/thud.wav", // হুক/মূল বার্তা
} as const;
export type SfxName = keyof typeof FILES;

// ভলিউম সংযত (০.২–০.৩৫), ভয়েসওভারকে ঢাকে না
const BASE_VOL: Record<SfxName, number> = { pop: 0.3, click: 0.26, whoosh: 0.28, swipe: 0.3, chime: 0.3, thud: 0.32 };

/** সিনের লোকাল ফ্রেম `at`-এ SFX। vary: পরপর একই সাউন্ডে সামান্য ভলিউম/গতি ভ্যারিয়েশন */
export const Sfx: React.FC<{ name: SfxName; at: number; vary?: number }> = ({ name, at, vary = 0 }) => {
  if (!ENABLE_SFX) return null;
  const v = [1, 0.88, 1.06, 0.94][((vary % 4) + 4) % 4];
  const rate = [1, 0.95, 1.06, 1.02][((vary % 4) + 4) % 4];
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={30} layout="none">
      <Audio src={staticFile(FILES[name])} volume={Math.min(0.35, BASE_VOL[name] * v)} playbackRate={rate} />
    </Sequence>
  );
};

// রেন্ডারিং কিনা — Remotion-এর সংস্করণভেদে যে API আছে সেটাই ব্যবহার হয়
const envFn = ((R as any).useRemotionEnvironment ?? (R as any).getRemotionEnvironment) as
  | undefined
  | (() => { isRendering?: boolean });

/**
 * public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজে; না থাকলে নীরবে বাদ।
 * রেন্ডারে ডিফল্টে বন্ধ (src/config.ts → INCLUDE_VO_IN_RENDER)।
 */
export const PreviewAudio: React.FC = () => {
  const isRendering = envFn ? !!envFn().isRendering : false;
  const enabled = PREVIEW_VOICEOVER && (!isRendering || INCLUDE_VO_IN_RENDER);
  const [found, setFound] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    const handle = delayRender("voiceover-check");
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (r.ok && !type.includes("text/html")) setFound(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
  }, [enabled]);

  if (!enabled || !found) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
