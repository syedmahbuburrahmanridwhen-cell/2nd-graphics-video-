import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme, alpha } from "../theme";

// লেয়ার ১: ব্যাকগ্রাউন্ড মেশ + ডট-গ্রিড (কখনো ফ্ল্যাট রঙ নয়)
type Blob = { x: number; y: number; size: number; ph: number };
const VARIANTS: Blob[][] = [
  [
    { x: 1250, y: -380, size: 1250, ph: 0 },
    { x: -450, y: 520, size: 1000, ph: 2 },
  ],
  [
    { x: -400, y: -420, size: 1150, ph: 1 },
    { x: 1150, y: 560, size: 1050, ph: 3 },
  ],
  [
    { x: 380, y: -560, size: 1300, ph: 2 },
    { x: 1300, y: 640, size: 900, ph: 0 },
  ],
];

export const BgMesh: React.FC<{ variant?: number }> = ({ variant = 0 }) => {
  const frame = useCurrentFrame();
  const blobs = VARIANTS[variant % VARIANTS.length];
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, overflow: "hidden" }}>
      {blobs.map((b, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            width: b.size,
            height: b.size,
            left: b.x + Math.sin(frame / 55 + b.ph) * 50,
            top: b.y + Math.cos(frame / 70 + b.ph) * 40,
            borderRadius: "50%",
            filter: `blur(${i === 0 ? 60 : 80}px)`,
            background: `radial-gradient(circle, ${alpha(i === 0 ? theme.colors.hero : theme.colors.accent, i === 0 ? 0.2 : 0.11)}, transparent 62%)`,
          }}
        />
      ))}
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.line} 1.4px, transparent 1.6px)`,
          backgroundSize: "64px 64px",
          backgroundPosition: `${(frame * 0.25) % 64}px ${(frame * 0.12) % 64}px`,
          opacity: 0.55,
          maskImage: "radial-gradient(ellipse at center, black 18%, transparent 78%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 18%, transparent 78%)",
        }}
      />
    </AbsoluteFill>
  );
};

// লেয়ার ৪: কালার গ্রেড (কনটেন্টের ওপরে, গ্রেনের নিচে)
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill
      style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.16), transparent 26%, transparent 74%, rgba(0,0,0,0.24))" }}
    />
  </AbsoluteFill>
);

// লেয়ার ৫ক: প্রসিডিউরাল গ্রেন
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

// লেয়ার ৫খ: ভিনিয়েট (সবার ওপরে)
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.34) 100%)",
    }}
  />
);
