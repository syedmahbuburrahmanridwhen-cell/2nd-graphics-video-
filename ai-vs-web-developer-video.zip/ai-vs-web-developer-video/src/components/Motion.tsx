import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, heroGradient, SpringCfg, theme } from "../theme";

export const clampX = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** bezier ইজিংসহ clamp-করা interpolate */
export const tween = (
  frame: number,
  [a, b]: [number, number],
  [x, y]: [number, number],
  easing: (t: number) => number = theme.ease.out,
) => interpolate(frame, [a, b], [x, y], { easing, ...clampX });

export const useSpr = (at: number, cfg: SpringCfg = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - at, fps, config: cfg });
};

/** idle breathing: স্ক্রিনে >২ সেকেন্ড থাকা উপাদানের মাইক্রো-মোশন */
export const useBreath = (period = 22, amp = 0.015, phase = 0) => 1 + Math.sin(useCurrentFrame() / period + phase) * amp;
export const useFloat = (period = 30, amp = 6, phase = 0) => Math.sin(useCurrentFrame() / period + phase) * amp;

type AppearProps = {
  at: number;
  until?: number; // এই ফ্রেমে বিদায় (১০ ফ্রেমের দ্রুত এক্সিট)
  y?: number;
  x?: number;
  from?: number; // শুরুর scale
  cfg?: SpringCfg;
  exit?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
};

/** প্রিমিয়াম এন্ট্রি: opacity + translate + scale একসাথে; এক্সিট এন্ট্রির চেয়ে দ্রুত */
export const Appear: React.FC<AppearProps> = ({ at, until, y = 36, x = 0, from = 0.94, cfg = theme.spring.smooth, exit = 10, style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < at || (until !== undefined && frame >= until)) return null;
  const p = spring({ frame: frame - at, fps, config: cfg });
  const out = until === undefined ? 0 : tween(frame, [until - exit, until], [0, 1], theme.ease.in);
  const s = (from + (1 - from) * p) * (1 - out * 0.05);
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.5) * (1 - out),
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y - out * 26}px) scale(${s})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

type WordsProps = {
  text: string; // "*শব্দ*" = হাইলাইট (গ্রেডিয়েন্ট), "~" = অবিভাজ্য স্পেস
  at: number;
  until?: number;
  size?: number;
  per?: number;
  align?: "left" | "center" | "right";
  color?: string;
  weight?: number;
  lineHeight?: number;
  y?: number;
  style?: React.CSSProperties;
};

/**
 * ওয়ার্ড-বাই-ওয়ার্ড স্ট্যাগার্ড রিভিল। বাংলা: বিভাজন শুধু স্পেসে, কখনো অক্ষরে নয়; letterSpacing 0।
 */
export const Words: React.FC<WordsProps> = ({ text, at, until, size = theme.size.h2, per = 4, align = "left", color = theme.colors.text, weight = theme.weight.bold, lineHeight = 1.2, y = 34, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < at || (until !== undefined && frame >= until)) return null;
  const out = until === undefined ? 0 : tween(frame, [until - 10, until], [0, 1], theme.ease.in);
  const tokens = text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.04),
        justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start",
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight,
        letterSpacing: 0,
        color,
        opacity: 1 - out,
        transform: `translateY(${-out * 24}px)`,
        ...style,
      }}
    >
      {tokens.map((tok, i) => {
        const hi = tok.startsWith("*") && tok.endsWith("*") && tok.length > 2;
        const label = (hi ? tok.slice(1, -1) : tok).replace(/~/g, "\u00A0");
        const p = spring({ frame: frame - at - i * per, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.6),
              transform: `translateY(${(1 - p) * y}px) scale(${0.92 + 0.08 * p})`,
              ...(hi
                ? {
                    // বাংলার মাত্রা/রেফ যাতে background-clip-এ কাটা না পড়ে: প্যাডিং + নেগেটিভ মার্জিন
                    padding: "0.16em 0.05em",
                    margin: "-0.16em -0.05em",
                    backgroundImage: heroGradient,
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    color: "transparent",
                    filter: `drop-shadow(0 0 ${Math.round(size * 0.2)}px ${theme.colors.glow})`,
                  }
                : {}),
            }}
          >
            {label}
          </span>
        );
      })}
    </div>
  );
};

/** অ্যাকসেন্ট পিল (ছোট বাউন্স-পপ) */
export const Pill: React.FC<{ children: React.ReactNode; tone?: "hero" | "accent" | "dim"; size?: number; style?: React.CSSProperties }> = ({ children, tone = "dim", size = theme.size.small, style }) => {
  const c = theme.colors;
  const map = {
    hero: { bg: c.hero, fg: c.ink, bd: "transparent" },
    accent: { bg: c.accentSoft, fg: c.accent, bd: alpha(c.accent, 0.4) },
    dim: { bg: c.surface, fg: c.text, bd: c.line },
  }[tone];
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 12,
        padding: `${Math.round(size * 0.34)}px ${Math.round(size * 0.8)}px`,
        borderRadius: theme.radius.pill,
        background: map.bg,
        color: map.fg,
        border: `1.5px solid ${map.bd}`,
        fontFamily: theme.fonts.display,
        fontWeight: theme.weight.bold,
        fontSize: size,
        lineHeight: 1.25,
        letterSpacing: 0,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {children}
    </div>
  );
};
