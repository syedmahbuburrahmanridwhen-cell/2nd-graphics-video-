import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { TRANSITION_FRAMES, WIDTH } from "../timing";
import { tween } from "./Motion";

/** সিন-ট্রানজিশন: তির্যক প্যানেল ঝাপটে যায়; কাট ঠিক মাঝে (প্যানেল পুরো ঢেকে রাখার সময়) */
export const TransitionPanel: React.FC = () => {
  const frame = useCurrentFrame();
  const W = WIDTH;
  const panelW = 2 * W + 400;
  const t = tween(frame, [0, TRANSITION_FRAMES], [0, 1], theme.ease.inOut);
  const left = -panelW + t * (panelW + W);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          top: -60,
          bottom: -60,
          left,
          width: panelW,
          transform: "skewX(-12deg)",
          background: `linear-gradient(90deg, ${theme.colors.bg}, ${theme.colors.bgAlt} 55%, ${theme.colors.bg})`,
          borderRight: `10px solid ${theme.colors.hero}`,
          borderLeft: `3px solid ${theme.colors.accent}`,
          boxShadow: `0 0 80px ${theme.colors.glow}`,
        }}
      />
    </AbsoluteFill>
  );
};
