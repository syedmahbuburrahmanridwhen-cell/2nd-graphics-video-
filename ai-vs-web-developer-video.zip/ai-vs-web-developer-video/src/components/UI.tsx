import React from "react";
import { Img, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { alpha, heroGradient, theme } from "../theme";
import { Appear } from "./Motion";

const c = theme.colors;

/** গ্লাস কার্ড — সারা ভিডিওতে একই গোলাকার ভাব ও ছায়া */
export const Glass: React.FC<{ children?: React.ReactNode; style?: React.CSSProperties; radius?: number; glow?: boolean }> = ({ children, style, radius = theme.radius.md, glow }) => (
  <div
    style={{
      background: `linear-gradient(150deg, ${c.surfaceStrong}, ${c.surface})`,
      border: `1.5px solid ${glow ? alpha(c.hero, 0.55) : c.line}`,
      borderRadius: radius,
      boxShadow: glow ? `${theme.shadow.card}, 0 0 70px ${c.glow}` : theme.shadow.card,
      ...style,
    }}
  >
    {children}
  </div>
);

/** ব্রাউজার ফ্রেম */
export const Browser: React.FC<{
  width: number;
  height: number;
  url?: string;
  glow?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({ width, height, url = "", glow, children, style }) => {
  const bar = 56;
  return (
    <div
      style={{
        width,
        height,
        borderRadius: 24,
        overflow: "hidden",
        background: c.bgAlt,
        border: `1.5px solid ${glow ? alpha(c.hero, 0.6) : c.line}`,
        boxShadow: glow ? `${theme.shadow.card}, 0 0 90px ${c.glow}` : theme.shadow.card,
        position: "relative",
        ...style,
      }}
    >
      <div style={{ height: bar, display: "flex", alignItems: "center", gap: 10, padding: "0 20px", background: c.surface, borderBottom: `1.5px solid ${c.lineSoft}` }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ width: 13, height: 13, borderRadius: 99, background: i === 0 ? c.textDim : c.line }} />
        ))}
        <div
          style={{
            marginLeft: 18,
            flex: 1,
            height: 34,
            borderRadius: 99,
            background: c.surface,
            border: `1px solid ${c.lineSoft}`,
            display: "flex",
            alignItems: "center",
            padding: "0 18px",
            fontFamily: theme.fonts.mono,
            fontSize: 20,
            color: c.textDim,
            letterSpacing: 0,
            whiteSpace: "nowrap",
            overflow: "hidden",
          }}
        >
          {url}
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: bar, bottom: 0, overflow: "hidden" }}>{children}</div>
    </div>
  );
};

type Block = { l: number; t: number; w: number; h: number; r?: number; bg: string; rot?: number; bd?: string; shadow?: string };
const P = (v: number) => `${v}%`;

/** ওয়েবসাইট মকআপ (শুধু ব্লক, ভুয়া টেক্সট নয়)। polished=false → এলোমেলো/ডিফল্ট ধাঁচ, true → পালিশড */
export const SiteMock: React.FC<{ polished: boolean; at: number; per?: number; minimal?: boolean }> = ({ polished, at, per = 4, minimal }) => {
  const dim = alpha(c.textDim, 0.3);
  const dimStrong = alpha(c.textDim, 0.5);
  const blocks: Block[] = polished
    ? [
        { l: 5, t: 5, w: 4.4, h: 7, r: 99, bg: c.hero },
        { l: 56, t: 6.2, w: 8, h: 4.4, r: 99, bg: dimStrong },
        { l: 66, t: 6.2, w: 8, h: 4.4, r: 99, bg: dimStrong },
        { l: 76, t: 6.2, w: 8, h: 4.4, r: 99, bg: dimStrong },
        { l: 86, t: 6.2, w: 9, h: 4.4, r: 99, bg: c.text },
        { l: 5, t: 22, w: 46, h: 8, r: 14, bg: c.text },
        { l: 5, t: 33, w: 36, h: 8, r: 14, bg: heroGradient },
        { l: 5, t: 47, w: 40, h: 2.6, r: 99, bg: dimStrong },
        { l: 5, t: 52, w: 32, h: 2.6, r: 99, bg: dim },
        { l: 5, t: 60, w: 17, h: 8.4, r: 99, bg: c.hero, shadow: `0 0 34px ${c.glow}` },
        { l: 24, t: 60, w: 15, h: 8.4, r: 99, bg: "transparent", bd: `2px solid ${c.line}` },
        { l: 58, t: 20, w: 37, h: 46, r: 28, bg: `linear-gradient(150deg, ${alpha(c.hero, 0.55)}, ${alpha(c.accent, 0.3)})`, shadow: `0 24px 60px -16px ${c.glow}` },
        { l: 5, t: 76, w: 28, h: 17, r: 20, bg: c.surfaceStrong, bd: `1.5px solid ${c.line}` },
        { l: 36, t: 76, w: 28, h: 17, r: 20, bg: c.surfaceStrong, bd: `1.5px solid ${c.line}` },
        { l: 67, t: 76, w: 28, h: 17, r: 20, bg: c.surfaceStrong, bd: `1.5px solid ${c.line}` },
      ]
    : [
        { l: 8, t: 8, w: 62, h: 7, r: 4, bg: dimStrong, rot: -1.6 },
        { l: 9, t: 22, w: 42, h: 32, r: 4, bg: dim, bd: `2px dashed ${dimStrong}`, rot: 0.8 },
        { l: 56, t: 29, w: 30, h: 13, r: 4, bg: dim, rot: -0.6 },
        { l: 8, t: 60, w: 70, h: 3, r: 2, bg: dim },
        { l: 8, t: 67, w: 51, h: 3, r: 2, bg: dim },
        { l: 8, t: 74, w: 64, h: 3, r: 2, bg: dim },
        { l: 11, t: 83, w: 21, h: 9, r: 3, bg: "transparent", bd: `2px solid ${dimStrong}`, rot: 1.4 },
        { l: 60, t: 80, w: 24, h: 6, r: 3, bg: dim, rot: -2 },
      ];
  const shown = minimal ? blocks.filter((_, i) => [0, 1, 4, 5, 6, 7, 9].includes(i)) : blocks;
  return (
    <div style={{ position: "absolute", inset: 0, background: polished ? `linear-gradient(180deg, ${c.bgAlt}, ${c.bg})` : c.bgAlt }}>
      {shown.map((b, i) => (
        <Appear
          key={i}
          at={at + i * per}
          y={18}
          from={0.9}
          cfg={theme.spring.snappy}
          style={{
            position: "absolute",
            left: P(b.l),
            top: P(b.t),
            width: P(b.w),
            height: P(b.h),
            borderRadius: b.r ?? 8,
            background: b.bg,
            border: b.bd,
            boxShadow: b.shadow,
            transformOrigin: "left center",
            rotate: b.rot ? `${b.rot}deg` : undefined,
          }}
        />
      ))}
    </div>
  );
};

/** ইউজারের ওয়েবসাইট স্ক্রিনশট + Ken Burns (প্রতিটি স্টিলে অবশ্যই)। scene-এর দৈর্ঘ্য জুড়ে ধীর জুম + প্যান */
export const Shot: React.FC<{ zoomTo?: number; pan?: number; style?: React.CSSProperties }> = ({ zoomTo = 1.08, pan = 160, style }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const k = theme.ease.inOut(Math.min(1, Math.max(0, frame / durationInFrames)));
  return (
    <Img
      src={staticFile("site-screenshot.png")}
      style={{
        width: "100%",
        display: "block",
        transformOrigin: "50% 0%",
        transform: `translateY(${-pan * k}px) scale(${1 + (zoomTo - 1) * k})`,
        ...style,
      }}
    />
  );
};
