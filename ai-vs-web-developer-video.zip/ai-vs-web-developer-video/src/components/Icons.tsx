import React from "react";
import { theme } from "../theme";

// সব আইকন SVG, থিমের রঙে — emoji নয়।
type IconProps = { size?: number; color?: string; stroke?: number; style?: React.CSSProperties };
const base = (size: number, style?: React.CSSProperties) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  style,
});

const mk =
  (paths: (c: string) => React.ReactNode): React.FC<IconProps> =>
  ({ size = 48, color = theme.colors.text, stroke = 2, style }) => (
    <svg {...base(size, style)} stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
      {paths(color)}
    </svg>
  );

export const IconCheck = mk(() => <path d="M5 12.5l4.5 4.5L19 7.5" />);
export const IconCross = mk(() => <path d="M6 6l12 12M18 6L6 18" />);
export const IconCode = mk(() => <path d="M8.5 7L3.5 12l5 5M15.5 7l5 5-5 5M13.6 5l-3.2 14" />);
export const IconSparkle = mk((c) => <path d="M12 3c.6 4.6 2.4 6.4 7 7-4.6.6-6.4 2.4-7 7-.6-4.6-2.4-6.4-7-7 4.6-.6 6.4-2.4 7-7z" fill={c} fillOpacity={0.18} />);
export const IconFolder = mk((c) => <path d="M3.5 7.5a2 2 0 012-2h4l2 2.2h7a2 2 0 012 2v7.8a2 2 0 01-2 2h-13a2 2 0 01-2-2V7.5z" fill={c} fillOpacity={0.14} />);
export const IconFile = mk((c) => <path d="M6.5 3.5h7l4 4v13h-11v-17zM13.5 3.5v4h4" fill={c} fillOpacity={0.1} />);
export const IconPerson = mk((c) => (
  <>
    <circle cx="12" cy="8.5" r="3.6" fill={c} fillOpacity={0.14} />
    <path d="M4.8 20c.9-3.8 3.6-5.6 7.2-5.6s6.3 1.8 7.2 5.6" />
  </>
));
export const IconBriefcase = mk((c) => (
  <>
    <rect x="3.5" y="7.5" width="17" height="12" rx="2.4" fill={c} fillOpacity={0.12} />
    <path d="M9 7.5v-1.6a1.4 1.4 0 011.4-1.4h3.2A1.4 1.4 0 0115 5.9v1.6M3.5 13h17" />
  </>
));
export const IconTag = mk((c) => (
  <>
    <path d="M3.5 12.2V4.5h7.7l9 9a1.6 1.6 0 010 2.3l-5.4 5.4a1.6 1.6 0 01-2.3 0l-9-9z" fill={c} fillOpacity={0.12} />
    <circle cx="8" cy="9" r="1.2" fill={c} />
  </>
));
export const IconStar = mk((c) => <path d="M12 3.6l2.6 5.4 5.9.8-4.3 4.1 1.1 5.9L12 17l-5.3 2.8 1.1-5.9-4.3-4.1 5.9-.8L12 3.6z" fill={c} fillOpacity={0.16} />);
export const IconBolt = mk((c) => <path d="M13 3L5.5 13.2h5.3L10 21l7.5-10.2h-5.3L13 3z" fill={c} fillOpacity={0.16} />);
export const IconGlobe = mk(() => (
  <>
    <circle cx="12" cy="12" r="8.6" />
    <path d="M3.4 12h17.2M12 3.4c2.6 2.4 3.8 5.3 3.8 8.6s-1.2 6.2-3.8 8.6c-2.6-2.4-3.8-5.3-3.8-8.6S9.4 5.8 12 3.4z" />
  </>
));
export const IconPlay = mk((c) => <path d="M8 5.2v13.6L19 12 8 5.2z" fill={c} />);
export const IconChat = mk((c) => <path d="M4.5 6.5a2.5 2.5 0 012.5-2.5h10a2.5 2.5 0 012.5 2.5v7a2.5 2.5 0 01-2.5 2.5H11l-4.5 3.8V16H7a2.5 2.5 0 01-2.5-2.5v-7z" fill={c} fillOpacity={0.12} />);
export const IconUpload = mk(() => <path d="M12 16V5M7.5 9.5L12 5l4.5 4.5M5 19h14" />);
export const IconQuestion = mk(() => (
  <>
    <path d="M9.2 9.2a2.9 2.9 0 115 2c-1.2.9-2.2 1.5-2.2 3" />
    <circle cx="12" cy="18.2" r="0.6" fill="currentColor" />
  </>
));
export const IconFlag = mk((c) => <path d="M6 20.5V4M6 5h11.5l-2.4 3.6 2.4 3.6H6" fill={c} fillOpacity={0.14} />);
export const IconPulse = mk(() => <path d="M3 12h4l2.2-6 4 12 2.4-6H21" />);
export const IconMail = mk((c) => (
  <>
    <rect x="3.5" y="5.5" width="17" height="13" rx="2.4" fill={c} fillOpacity={0.12} />
    <path d="M4 7.5l8 6 8-6" />
  </>
));

/** মাউস কার্সর (ফিল্ড, সাদা + ছায়া) */
export const Cursor: React.FC<{ size?: number; style?: React.CSSProperties }> = ({ size = 56, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{ filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.55))", ...style }}>
    <path d="M5 3.2l13.2 7.6-5.6 1.6-2.4 5.6L5 3.2z" fill={theme.colors.text} stroke={theme.colors.ink} strokeWidth={1.4} strokeLinejoin="round" />
  </svg>
);
