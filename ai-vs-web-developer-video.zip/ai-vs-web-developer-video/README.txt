AI vs Web Developer — Remotion মোশন গ্রাফিক্স (1920x1080, 30fps, কম্পোজিশন ID: Main)

1) npm install
2) npx remotion studio          (প্রিভিউ)
3) npx remotion render src/index.ts Main out/video.mp4

- ভয়েসওভার: public/voiceover.mp3 রাখলে Studio প্রিভিউতে বাজবে। রেন্ডারে মেশাতে src/config.ts-এ INCLUDE_VO_IN_RENDER = true।
- SRT বদলালে: script/2nd_video.srt বদলে `npm run cues`। সব সময় src/cues.ts থেকে আসে।
- SFX আবার বানাতে: `npm run sfx`।
- রং/ফন্ট/ইজিং: src/theme.ts।
